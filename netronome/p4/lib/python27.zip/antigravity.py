
import webbrowser

webbrowser.open("http://xkcd.com/353/")
