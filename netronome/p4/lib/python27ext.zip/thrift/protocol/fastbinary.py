def __bootstrap__():
    global __bootstrap__, __loader__, __file__
    import sys, imp
    __loader__ = None; del __bootstrap__, __loader__
    imp.load_dynamic(__name__,imp.find_module('fastbinary')[1])
__bootstrap__()
