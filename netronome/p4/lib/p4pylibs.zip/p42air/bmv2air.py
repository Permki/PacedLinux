import os, sys, json, yaml, traceback, datetime, argparse, pprint, time
import collections, warnings, copy

from p42air_base import P42AIRBaseError

VERSION = '0.1.0'
DESCRIPTION = 'Convert BMV2 json to AIR yaml.'    

PARSER_OPS = {
    'extract': 'extracts',
    'set': 'sets',
    'extract_VL': 'extracts',
}

REWRITE_ACT_OPS = {
    'assign': 'modify_field',
    'assign_header': 'copy_header',
}

REWRITE_ACTS = {
    '__HIT__': 'hit',
    '__MISS__': 'miss',
    'default': 'default',
}

UNARY_OPS = ('-', '~', '!', 'not', 'b2d', 'd2b')


FIELD_LIST_APIS = {
#    'generate_digest': 1,               #(receiver, field_list)
    'resubmit': 0,                      #(field_list)
    'recirculate': 0,                   #(field_list)
    'clone_ingress_pkt_to_ingress': 1,  #(clone_spec, field_list)
    'clone_egress_pkt_to_ingress': 1,   #(clone_spec, field_list)
    'clone_ingress_pkt_to_egress': 1,   #(clone_spec, field_list)
    'clone_egress_pkt_to_egress': 1,    #(clone_spec, field_list)
}

ALGO_OUTPUT_WIDTH = {
    'crc32': 32,
    'crc32_custom': 32,
    'crc16': 16,
    'crc16_custom': 16,
    #random,
    #identity,
    'csum16': 16,
    'xor16': 16,
}     
UNKNOWN_ALGO_OUTPUT_WIDTH = 32

DISABLE_SCOPING_FOR_P4_14 = True

YAML_SECTIONS = [
    ('header_layout',           'Header layout definitions'),
    ('headers',                 'Header instance definitions'),
    ('meters',                  'Meters definitions'),
    ('registers',               'Register definitions'),
    ('field_lists',             'Field list definitions'),
    ('field_list_calculations', 'Field list calculations'),
    ('parser_expressions',      'Parser Expressions'),
    ('parse_states',            'Parse states'),
    ('parsers',                 'Parser'),
    ('external_functions',      'External functions'),
    ('digests',                 'Digests'),
    ('action_expressions',      'Action Expressions'),
    ('action_sets',             'Action sets'),
    ('tables',                  'Ingress and Egress tables'),
    ('ingress_conditionals',    'Ingress conditionals sets'),
    ('ingress_control_flow',    'Ingress control flow'),
    ('egress_conditionals',     'Egress conditionals sets'),
    ('egress_control_flow',     'Egress control flow'),
    ('deparsers',               'Deparsers'),
    ('processor_layout',        'Processor layout'),
    ('source_info',             'Source info'),
]

class BMV2AIRError(P42AIRBaseError):
    pass

class implementation(str):
    pass
    
def multiline_str_presenter(dumper, data):
    """ yaml dumper helper that forces pretty multiline string output """
    if len(data.splitlines()) > 1:
        return dumper.represent_scalar('tag:yaml.org,2002:str', data, style='|')
    return dumper.represent_scalar('tag:yaml.org,2002:str', data)

yaml.SafeDumper.add_representer(implementation, multiline_str_presenter)


class BMV2Reader(object):

    def __init__(self, data, outputfile, p4version):
        self.output_file = outputfile
        self.p4_version = p4version
        self.source_files = set()
        
        
        self.yml = {}
        for name, label in YAML_SECTIONS:
            self.yml[name] = {}

        self._scopes = {
            'header': {},
        }

        self._headers = {}
        self._headers_by_id = {}
        self._header_union_by_header_id = {}
        self._actions_by_id = {}
        self._actions_by_pipeline = {}
        self._pipeline_for_action = {}
        self._tables_by_pipeline = {}
        self._counter_types = {}
        self._checksum_calcs = {}
        self._field_list_by_id = {}
        self._field_list_by_name = {}
        self._field_list_id_max = 0
        self._stacked_header_depths = {}
        self._expr_name_count = {}
        self._conditional_exits = {
            'ingress_conditionals': {},
            'egress_conditionals': {},
        }
        self._condition_renames = {}
        self._learn_lists = {}
        self._parse_graph_transitions = []
        self._flow_graphs = {
            'ingress': {
                'conditionals': collections.OrderedDict(),
                'transitions': [],
            },
            'egress': {
                'conditionals': collections.OrderedDict(),
                'transitions': [],
            },
        }
        
        self.process(data)

    def process(self, data):
        self.process_scopes(data)
        self.pre_process_headers(data)
        self.process_field_lists(data)
        self.process_parsers(data)
        self.process_extern_functions(data)
        self.process_learn_lists(data)
        self.process_registers(data)
        self.pre_process_actions(data)
        self.process_pipelines(data)
        self.process_meters(data)
        self.process_layout(data)
        self.process_source_info(data)

        self.process_headers(data)
        self.process_actions(data)
        self.process_deparsers(data)

    def process_scopes(self, data):
        def process_header_scopes(scopes, context):
            for header, field, name, pipeline, action in scopes:
                stacked, hsname, slvl = self.is_stacked_header(header)
                if stacked:
                    header = hsname
                for hname, hdr, ht, stacked, slvl in self.traverse_headers(data):
                    if hname == header:
                        break
                else:
                    raise Exception, 'header not found: %s'%header
            
                scope = self._scopes['header'].setdefault(header, set())
                # non metadata headers, standard and intrinsic metadata are always global scope
                if hdr['header_type'] in ('standard_metadata', 'intrinsic_metadata_t'):
                    scope.add(header)
                    continue
                elif not hdr['metadata']:
                    if stacked:
                        dep_header = '%s[%d]'%(header, slvl)
                    else:
                        dep_header = header
                    if dep_header in data['deparsers'][0]['order']:
                        scope.add(header)
                        continue

                if context == 'global':
                    scope.add(self.as_scoped_name(header))
                elif context == 'parser':
                    scope.add(self.as_scoped_name(header, 'parser'))
                elif context == 'actions':
                    scope.add(self.as_scoped_name(header, pipeline, action))
                elif context == 'pipeline':
                    scope.add(self.as_scoped_name(header, pipeline))

        def reduce_scopes(header, scopes):
            globl = False
            flows = set()
            actions = set()
            for scope in scopes:
                segs = scope.split('::')
                flow = None
                flow_act = None
                action = None
                if len(segs) == 1:
                    name = segs[0]
                elif len(segs) == 2:
                    flow, name = segs
                else:
                    flow_act, action, name = segs
                
                if action:
                    actions.add((flow_act, action))
                if flow:
                    flows.add(flow)
                if not flow and not action:
                    globl = True

            # more than one flow cannot be shared, always global
            if len(actions) and len(flows) <= 1 and not globl:
                # more than one action, must share flows otherwise global
                if len(actions) > 1:
                    act_flows = set([a[0] for a in actions])
                    if len(act_flows) == 1 and ((flows and act_flows == flows) or not flows):
                        return self.as_scoped_name(name, act_flows.pop())
                # one action
                else:
                    af, an = actions.pop()
                    if not flows:
                        # action local if not already flow local
                        return self.as_scoped_name(name, af, an)
                    # must be flow local if there is a flow
                    elif af in flows:
                        return self.as_scoped_name(name, af)
            elif len(flows) == 1 and not globl:
                return self.as_scoped_name(name, flows.pop())
                        
            return name

        global_scopes = []
        pipeline_scopes = []
        parser_scopes = []
        action_scopes = []
            
        # record stacked header max depths
        for hdr in data['headers']:
            stacked, hname, slvl = self.is_stacked_header(hdr['name'])
            if stacked:
                self._stacked_header_depths.setdefault(hname, 0)
                self._stacked_header_depths[hname] += 1

        # record field list mappings
        for fl in data['field_lists']:
            self._field_list_by_id[fl['id']] = fl['name']
            self._field_list_by_name[fl['name']] = fl
            self._field_list_id_max = max(self._field_list_id_max, fl['id'])

        # traverse checksums for target, condition and field list scope tracing
        for cks in data['checksums']:
            self.trace_target(global_scopes, cks['target'], None, None)
            if 'if_cond' in cks:
                self.trace_typed_value(global_scopes, cks['if_cond'], None, None)
            for calc in data['calculations']:
                if calc['name'] == cks['calculation']:
                    self.trace_params(global_scopes, calc['input'], calc['name'])
                    break
            else:
                raise BMV2AIRError, 'calculation %s not found'%cks['calculation']

            # record checksum calculations
            if cks['type'] == 'payload':
                self._checksum_calcs[cks['calculation']] = cks['type']


        # trace tables and setup group actions on id by pipeline
        for pl in data['pipelines']:
            # trace conditional exprs
            for cond in pl['conditionals']:
                self.trace_typed_value(pipeline_scopes, cond['expression'], None, pl['name'])

            for tbl in pl['tables']:
                for act_id, act_name in zip(tbl['action_ids'], tbl['actions']):
                    if act_name == 'NoAction':
                        continue
                    self._pipeline_for_action[act_id] = pl['name']

                if pl['name'] not in self._tables_by_pipeline:
                    self._tables_by_pipeline[pl['name']] = set()
                self._tables_by_pipeline[pl['name']].add(tbl['name'])# XXX sname
                
                # trace match fields
                for key in tbl['key']:
                    self.trace_target(pipeline_scopes, key['target'], None, pl['name'])
                                    
        # trace parser scopes
        for prs in data['parsers']:
            for ps in prs['parse_states']:
                for po in ps['parser_ops']:
                    ops_list = []
                    if po['op'] == 'primitive':
                        ops_list.extend(po['parameters'])
                    else:
                        ops_list.append(po)
                    
                    for sub_op in ops_list:
                        self.trace_params(parser_scopes, sub_op['parameters'], ps['name'], 'parser')

        # extract scope information from action primitives
        for act in data['actions']:
            if act['primitives']:
                for op in act['primitives']:
                    pl = self._pipeline_for_action.get(act['id'], None)
                    self.trace_params(action_scopes, op['parameters'], act['name'], pl, act['name'])
                    if op['op'] in FIELD_LIST_APIS:
                        pidx = FIELD_LIST_APIS[op['op']]
                        assert op['parameters'][pidx]['type'] == 'hexstr'
                        lidx = int(op['parameters'][pidx]['value'], 16)
                        if lidx in self._field_list_by_id:
                            fl_name = self._field_list_by_id[lidx]
                            # trace the field list elements with a global scope
                            self.trace_params(global_scopes, self._field_list_by_name[fl_name]['elements'], fl_name)
                        else:
                            raise BMV2AIRError, 'could not find field list by id: %s'%lidx
                    elif op['op'] == 'generate_digest':
                        assert op['parameters'][0]['type'] == op['parameters'][1]['type'] == 'hexstr'
                        dgst_id = int(op['parameters'][0]['value'], 16)
                        ll_id = int(op['parameters'][1]['value'], 16)
                        for ll in data['learn_lists']:
                            if ll['id'] == ll_id:
                                self.trace_params(action_scopes, ll['elements'], act['name'], pl, act['name'])

        process_header_scopes(global_scopes, 'global')
        process_header_scopes(parser_scopes, 'parser')
        process_header_scopes(pipeline_scopes, 'pipeline')
        process_header_scopes(action_scopes, 'actions')

        # reduce set of scope usage by promoting scopes upward
        for header, scopes in self._scopes['header'].items()[:]:
            self._scopes['header'][header] = reduce_scopes(header, scopes)

    def decorate_netro_annotations(self, bmv2_json, air_yml):
        if 'netro_annotations' in bmv2_json:
            air_yml['pragmas'] = ['netro %s'%na for na in bmv2_json['netro_annotations']]

    def trace_target(self, scopes, target, name, pipeline=None, action=None):
        scopes.append( (target[0], target[1], name, pipeline, action) )
 
    def trace_params(self, scopes, params, name, pipeline=None, action=None):
        return [self.trace_typed_value(scopes, param, name, pipeline, action) 
                for param in params]
    
    def trace_typed_value(self, scopes, param, name, pipeline=None, action=None):
        if param['type'] == 'expression':
            return self.trace_expr_to_str(scopes, param, name, pipeline, action)
        elif param['type'] in ('field', 'stack_field'):
            scopes.append( (param['value'][0], param['value'][1], name, pipeline, action) )
        elif param['type'] in ('regular', 'header', 'stack'): 
            scopes.append( (param['value'], None, name, pipeline, action) )
        return

    def trace_expr_to_str(self, scopes, expr, name='unknown', pipeline=None, action=None):
        if 'type' in expr['value']:
            return self.trace_typed_value(scopes, expr['value'], name, pipeline, action)
        elif 'op' in expr['value']:
            op = expr['value']['op']
            left = expr['value']['left']
            right = expr['value']['right']
            right = (self.trace_expr_to_str(scopes, right, name, pipeline, action) 
                if 'op' in right else self.trace_typed_value(scopes, right, name, pipeline, action))
            if left is None and op in UNARY_OPS:
                return
            else:    
                assert left is not None, 'unhandled operation: %s'%op
                if 'op' in left:
                    self.trace_expr_to_str(scopes, left, name, pipeline, action) 
                else:
                    self.trace_typed_value(scopes, left, name, pipeline, action)
                if op == '?': # ternary
                    cond = expr['value']['cond']
                    if 'op' in cond:
                        self.trace_expr_to_str(scopes, cond, name, pipeline, action)
                    else:
                        self.trace_typed_value(scopes, cond, name, pipeline, action)
                        
                return
        else:
            raise BMV2AIRError, 'unexpected expression dict'
                
    def process_actions(self, data):
        for ai, (an, ad) in self._actions_by_id.items():
            if an == 'NoAction':
                continue
            pl = self._pipeline_for_action.get(ai, None)
            self.yml['action_sets'][self.as_scoped_name(an, pl)] = ad

    def traverse_headers(self, data):
        stacked_header_names = set()
        for hdr in data['headers']:
            # stacked headers
            stacked, hname, slvl = self.is_stacked_header(hdr['name'])
            if stacked:
                if hname in stacked_header_names:
                    continue
                name = hname
                stacked_header_names.add(name)
            else:
                name = hdr['name']

            for ht in data['header_types']:
                if ht['name'] == hdr['header_type']:
                    break
            else:
                raise BMV2AIRError, 'header type %s not found'%hdr['header_type']
            
            yield name, hdr, ht, stacked, slvl
        

    def is_stacked_header(self, name):
        if '[' in name and ']' in name:
            hname, slvl = name.split('[', 1)
            slvl = int(slvl.split(']', 1)[0])
            return True, hname, slvl
        else:
            return False, name, None
    
    def pre_process_headers(self, data):
        # header unions
        for hu in data['header_unions']:
            for hi in hu['header_ids']:
                self._header_union_by_header_id[hi] = hu['id']
                
        # headers
        for name, hdr, ht, stacked, slvl in self.traverse_headers(data):
            # do not dump scalars if it wasn't used
            if hdr['name'] == 'scalars' and not ht['fields']:
                continue

            name = name.replace('.', '@')
            fields = []
            for fld in ht['fields']:
                if len(fld) == 3:
                    fld_name, fld_width, fld_signed = fld
                else:
                    fld_name, fld_width = fld[:2]
                    if fld_width == '*':
                        fld_width = 0
                    fld_signed = False
                fld_value = fld_width if not fld_signed else {'width': fld_width, 'signed': True}
                fld_name = fld_name.replace('.', '@')
                fields.append( {fld_name: fld_value} )
                
            self._headers[name] = hdry = {
                'type': 'metadata' if hdr['metadata'] else 'header',
                'fields': fields,
            }
            self._headers_by_id[hdr['id']] = name
            if hdr['id'] in self._header_union_by_header_id:
                hdry['union'] = self._header_union_by_header_id[hdr['id']]
            
            if stacked:
                hdry['max_depth'] = self._stacked_header_depths[name]

            self.decorate_netro_annotations(hdr, hdry)

            if 'max_length' in ht:
                hdry['max_length'] = ht['max_length']

        # add checksums
        for cks in data['checksums']:
            hdr = self._headers[cks['target'][0]]
            if 'calculated_fields' not in hdr:
                hdr['calculated_fields'] = []
            if 'if_cond' in cks:
                cond = self.flatten_typed_value(cks['if_cond'], in_expr=True)
                # always execute
                if cond == 1:
                    cond = ''
                # strip outer brackets for pif expr parse limitation
                else:
                    assert cond[0] == '(' and cond[-1] == ')'
                    cond = cond[1:-1]
            hdr['calculated_fields'].append({
                'field': cks['target'][1],
                'type': 'verify' if cks.get('verify', False) else 'update', 
                'func': cks['calculation'],
                'condition': cond, 
            })
        
        if data['errors']:
            self._headers['errors'] = {
                'type': 'enum',
                'values': [{err_name: err_value} for err_name, err_value in data['errors']],
            }

    def process_meters(self, data):
        for mtr in data['meter_arrays']:
            self.yml['meters'][mtr['name']] = mtry = {
                'type': 'meter',
                'class' : 'direct' if mtr['is_direct'] else 'global',
                'meters': mtr['type'],
                'instance_count': 1 if mtr['is_direct'] else mtr.get('size', 1),
                # XXX rate_count
            }
            if mtr['is_direct']:
                mtry['table'] = self.resolve_binding(mtr['binding'])
            self.decorate_netro_annotations(mtr, mtry)
        
    def process_registers(self, data):
        for cntr in data['counter_arrays']:
            self.yml['registers'][cntr['name']] = regsy = {
                'type': 'register',
                'class' : 'direct' if cntr['is_direct'] else 'global',
                'instance_count': 1 if cntr['is_direct'] else cntr.get('size', 1),
                'fields': [ 
                ],
                'counts': [
                ],
            }
            if cntr['is_direct']:
                regsy['table'] = self.resolve_binding(cntr['binding'])
            self.decorate_netro_annotations(cntr, regsy)

            if 'type' not in cntr:
                warnings.warn('counter %s has no "type" set'%cntr['name'])
            
            cntr_type = cntr['type'] if 'type' in cntr else 'packets'
            self._counter_types[cntr['name']] = cntr_type
            if cntr_type in ('packets', 'both', 'packets_and_bytes'):
                regsy['fields'].append({'value_packets': 64})
                regsy['counts'].append({'packets': 'value_packets'})
            if cntr_type in ('bytes', 'both', 'packets_and_bytes'):
                regsy['fields'].append({'value_bytes': 64})
                regsy['counts'].append({'bytes': 'value_bytes'})

        for reg in data['register_arrays']:
            self.yml['registers'][reg['name']] = regsy = {
                'type': 'register',
                'class' : 'global',
                'instance_count': reg.get('size', 1),
                'fields': [ 
                    {'value': reg['bitwidth']},
                ],
            }
            self.decorate_netro_annotations(reg, regsy)

    def process_field_lists(self, data):
        def resolve_field_list_value(field):
            if field['type'] == 'hexstr':
                if 'bitwidth' in field:
                    bw = field['bitwidth']
                else:
                    bw = len(field['value'][2:])*4
                return '%dw%d'%(bw, int(field['value'], 16))
            else:
                return self.flatten_typed_value(field)

        for fl in data['field_lists']:
            self.yml['field_lists'][fl['name']] = fly = {
                'type': 'field_list',
                'fields': [resolve_field_list_value(f) for f in fl['elements']],
            }

        for calc in data['calculations']:
            inputs = []
            for f in calc['input']:
                if isinstance(f, dict):
                    inputs.append(resolve_field_list_value(f))
                elif isinstance(f, list):
                    for ff in f:
                        if ff['type'] == 'header':
                            if ff['value'] in self._headers:
                                for fld in self._headers[ff['value']]['fields']:
                                    inputs.append('%s.%s'%(ff['value'], fld.keys()[0]))
                            else:
                                raise BMV2AIRError, 'header "%s" not found'%ff['value']
                        # XXX correct to handle bitwidth hexstr here
                        else:
                            inputs.append(resolve_field_list_value(ff))
                else:
                    raise BMV2AIRError, 'unhandled calculation input item type: %s'%type(f)
            
            # XXX bmv2 now adds a special payload field in the calculation fields
            # add a payload field for payload checksums
            #if (calc['name'] in self._checksum_calcs and 
            #        self._checksum_calcs[calc['name']] == 'payload' and
            #        'payload' not in inputs):
            #    inputs.append('payload')

            if 'output_width' not in calc:
                warnings.warn('no output width available for field list calculation %s, '
                              'using default.'%calc['name'])

            # create fieldlist from calc inputs
            # see if it already defined
            field_list = self.add_field_list(inputs)
            self.yml['field_list_calculations'][calc['name']] = calcy = {
                'type': 'field_list_calculation',
                'algorithm': calc['algo'],
                'output_width': calc.get('output_width', ALGO_OUTPUT_WIDTH.get(
                    calc['algo'], UNKNOWN_ALGO_OUTPUT_WIDTH)),
                'inputs': [field_list],
            }
        
    def as_scoped_name(self, name, pipeline=None, action=None):
        if DISABLE_SCOPING_FOR_P4_14 and self.p4_version != '16':
            return name
        
        res = [name]
        if name.startswith('_condition_'):
            return name
        if action is not None:
            res.insert(0, action)
        if pipeline is not None:
            res.insert(0, pipeline)
        return '::'.join(res)

    def resolve_binding(self, binding):
        # XXX what does it mean that table names can now start with a dot?
        if binding.startswith('.'):
            binding = binding[1:]
        pl = None
        if 'ingress' in self._tables_by_pipeline and binding in self._tables_by_pipeline['ingress']:
            pl = 'ingress'
        elif 'egress' in self._tables_by_pipeline and binding in self._tables_by_pipeline['egress']:
            pl = 'egress'
        return self.as_scoped_name(binding, pl)

    def register_expression(self, context, name, expr):
        # check if expression can be resolved to a constant int
        try:
            expr_res = eval(expr)
        except Exception, err:
            pass
        else:
            if isinstance(expr_res, (int, long)):
                return expr_res
            
        if name not in self._expr_name_count:
            self._expr_name_count[name] = 0
        uname = '_expression_%s_%s'%(name, self._expr_name_count[name])
        self.yml[context][uname] = {
            'type': 'expression',
            'format': 'bracketed_expr',
            'expression': expr,
        }
        self._expr_name_count[name] += 1
        return uname

    def gen_params(self, params, runtime_data, context, name, preserve_hex=False):
        return [self.flatten_typed_value(param, runtime_data, context, name, False, preserve_hex) 
                for param in params]
    
    def flatten_typed_value(self, param, runtime_data=(), context='none', 
            name='unknown', in_expr=False, preserve_hex=False):
        assert 'type' in param, 'type field required, found: %s'%str(param)
        if param['type'] in ('field', 'stack_field'):
            values = [v.replace('.', '@') for v in param['value']]
            if values[0] in self._scopes['header']:
                values[0] = self._scopes['header'][values[0]]
            # rewrite $valid$ field usage
            if values[-1] == '$valid$':
                return 'valid(%s)'%('.'.join(values[:-1]))
            else:
                return '.'.join(values)
        elif param['type'] in ('regular', 'header', 'stack'):
            if param['value'] in self._scopes['header']:
                return self._scopes['header'][param['value']].replace('.', '@')
            else:
                return param['value'].replace('.', '@')
        elif param['type'] in ('calculation',  'meter_array', 'counter_array'):
            return param['value']
        elif param['type'] == 'register_array':
            return '%s.value'%param['value']
        elif param['type'] == 'header_stack': # XXX always 0 ?
            # XXX check scoping!!!
            return '%s[0]'%param['value']
        elif param['type'] == 'hexstr':
            if preserve_hex:
                return param['value']
            else:
                return int(param['value'], 16)
        elif param['type'] == 'lookahead':
            return self.register_expression(context, name, '($current(%d, %d))'%tuple(param['value']))
        elif param['type'] == 'bool': 
            return param['value']
        elif param['type'] == 'payload': 
            assert param['value'] is None
            return 'payload'
        elif param['type'] in ('runtime_data', 'local'): 
            return runtime_data[param['value']]['name']
        elif param['type'] == 'expression':
            if not in_expr:
                in_expr = True
                return self.register_expression(context, name, self.expr_to_str(param, runtime_data, context, name, in_expr, preserve_hex))
            else:
                return self.expr_to_str(param, runtime_data, context, name, in_expr, preserve_hex)
        else:
            raise BMV2AIRError, 'unhandled parameter type: %s'%param['type']

    def expr_to_str(self, expr, runtime_data, context='none', name='unknown', in_expr=False, preserve_hex=False):
        if 'type' in expr['value']:
            return self.flatten_typed_value(expr['value'], runtime_data, context, name, in_expr, preserve_hex)
        elif 'op' in expr['value']:
            op = expr['value']['op']
            left = expr['value']['left']
            right = expr['value']['right']
            right = (self.expr_to_str(right, runtime_data, context, name, in_expr, preserve_hex) 
                if 'op' in right else self.flatten_typed_value(right, runtime_data, context, name, in_expr, preserve_hex))
            if left is None and op in UNARY_OPS:
                # rewrite b2d/d2b
                if op in ('b2d', 'd2b'):
                    if isinstance(right, bool):
                        return '(%d)'%int(right)
                    else:
                        return '(%s)'%right
                else:
                    return '(%s(%s))'%(op, right)
            else:    
                assert left is not None, 'unhandled operation: %s'%op
                left = (self.expr_to_str(left, runtime_data, context, name, in_expr, preserve_hex) 
                    if 'op' in left else self.flatten_typed_value(left, runtime_data, context, name, in_expr, preserve_hex))
                if op == 'two_comp_mod': # signed cast
                    return '(icast (%s) (%s))'%(right, left)
                if op == '?': # ternary
                    cond = expr['value']['cond']
                    cond = (self.expr_to_str(cond, runtime_data, context, name, in_expr, preserve_hex)
                        if 'op' in cond else self.flatten_typed_value(cond, runtime_data, context, name, in_expr, preserve_hex))
                    return '((%s) ?: (%s) (%s))'%(cond, left, right)
                return '((%s) %s (%s))'%(left, op, right)
        else:
            raise BMV2AIRError, 'unexpected expression dict'

    def process_parsers(self, data):
        parse_states_by_name = {}
        known_states = set()
        def recurse_transitions(state, dg_trans):
            if state in known_states:
                return
            else:
                known_states.add(state)
            
            _recurse = []    
            for order, transition in enumerate(parse_states_by_name[state]['transitions']):
                value = transition['value']
                mask = 'none' if transition['mask'] is None else transition['mask']
                next_state = transition['next_state'] if transition['next_state'] is not None else 'exit'
                dg_trans.append({
                    'src': state, 
                    'dest': next_state,
                    'order': order,
                    'mask': mask,
                    'value': value,
                })
                
                if transition['next_state'] is not None:
                    _recurse.append( (next_state, dg_trans) )
            
            for next_state, dg_trans in _recurse:
                recurse_transitions(next_state, dg_trans)

        # parser and parse states
        for prs in data['parsers']:
            parse_states = []
            transitions = []
            
            parse_states_by_name = {}
            for ps in prs['parse_states']:
                parse_states_by_name[ps['name']] = ps
                
                self.yml['parse_states'][ps['name']] = psy = {
                    'type': 'parse_state',
                    'src_filename': ps['source_info']['filename'],
                    'src_lineno': ps['source_info']['line'],
                }

                if 'header_ordering' in ps:
                    psy['pragmas'] = ['header_ordering %s'%(' '.join(ps['header_ordering']))]
                
                impl = []
                for po in ps['parser_ops']:
                    ops_list = []
                    if po['op'] == 'primitive':
                        ops_list.extend(po['parameters'])
                    else:
                        ops_list.append(po)

                    for sub_op in ops_list:
                        params = self.gen_params(sub_op['parameters'], [], 'parser_expressions', ps['name'])
                        impl.append('%s(%s);'%(sub_op['op'], ', '.join([str(p) for p in params])))
                    
                if impl:
                    psy['implementation'] = implementation('\n'.join(impl))
                
                for tkey in ps['transition_key']:
                    if 'select_value' not in psy:
                        psy['select_value'] = []
                    psy['select_value'].append(self.flatten_typed_value(tkey))
                
            self._parse_graph_transitions = []
            known_states = set()
            recurse_transitions(prs['init_state'], self._parse_graph_transitions)

            transitions = '\n'.join([
                '    %(src)s -> %(dest)s [value="%(value)s", mask="%(mask)s", order="%(order)d"]'%t
                for t in self._parse_graph_transitions])
                        
            self.yml['parsers'][prs['name']] = {
                    'type': 'parser',
                    'format': 'dot',
                    'start_state': prs['init_state'],
                    'implementation': implementation('digraph {\n%s\n}'%str(transitions)),
                }

    def add_field_list(self, elems):
        field_list = None
        for fln, flv in self.yml['field_lists'].items():
            if flv['fields'] == elems:
                field_list = fln
                break
        
        if field_list is None:
            self._field_list_id_max += 1
            field_list = 'field_list_%d'%self._field_list_id_max
            self.yml['field_lists'][field_list] = {
                'type': 'field_list',
                'fields': elems,
            }
            self._field_list_by_id[self._field_list_id_max] = field_list
        
        return field_list
    
    def process_learn_lists(self, data):
        for ll in data['learn_lists']:
            elems = [self.flatten_typed_value(f) for f in ll['elements']]
            field_list = self.add_field_list(elems)
            self._learn_lists[ll['id']] = {
                'field_list': field_list,
                'name': ll['name'],
            }
                
    def pre_process_actions(self, data):
        for act in data['actions']:
            acty = {
                'type': 'action',
                'src_filename': act.get('source_info', {'filename': ''})['filename'],
                'src_lineno': act.get('source_info', {'line': 1})['line'],
            }
            self._actions_by_id[act['id']] = (act['name'], acty)
            self.source_files.add(act.get('source_info', {'filename': ''})['filename'])
            self.decorate_netro_annotations(act, acty)            

            if act['primitives']:
                impl = []

                # preprocess ops to expand count ops and link direct counters
                primitives = copy.deepcopy(act['primitives'])
                idx = 0
                for op in copy.deepcopy(primitives):
                    if op['op'] == 'count' and op['parameters'][0]['type'] == 'counter_array':
                        cntr_name = op['parameters'][0]['value']
                        cntr_type = self._counter_types[cntr_name]
                        if cntr_type in ('packets', 'both', 'packets_and_bytes'):
                            primitives[idx]['parameters'][0]['value'] = \
                                '%s.value_packets'%op['parameters'][0]['value']
                        elif cntr_type == 'bytes':
                            primitives[idx]['op'] = 'count_bytes'
                            primitives[idx]['parameters'][0]['value'] = \
                                '%s.value_bytes'%op['parameters'][0]['value']
                        
                        if cntr_type in ('packets_and_bytes', 'both'):
                            primitives.insert(idx+1, {
                                'op': 'count_bytes',
                                'parameters': [{
                                    'type': 'counter_array',
                                    'value': '%s.value_bytes'%op['parameters'][0]['value'],
                                }] + op['parameters'][1:],
                            })
                            idx += 1
                    idx += 1

                for op in primitives:
                    op_name = op['op']
                    op_params = op['parameters']
                    op_name = REWRITE_ACT_OPS.get(op_name, op_name)

                    parameters = [str(p) for p in self.gen_params(op_params, 
                        act['runtime_data'], 'action_expressions', act['name'], preserve_hex=True)]

                    if op_name == 'generate_digest':
                        dgst_id, ll_id = parameters
                        dgst_id, ll_id = int(dgst_id, 16), int(ll_id, 16)
                        field_list = self._learn_lists[ll_id]['field_list']
                        dgst_name = '_digest_%s_%d'%(self._learn_lists[ll_id]['name'], dgst_id)
                        if dgst_name not in self.yml['digests']:
                            self.yml['digests'][dgst_name] = {
                                'type': 'digest',
                                'identifier': dgst_id,
                                'field_list': field_list,
                            }
                        parameters = [dgst_name]
                        
                    elif op_name in FIELD_LIST_APIS:
                        pidx = FIELD_LIST_APIS[op_name]
                        lidx = int(parameters[pidx], 16)
                        if lidx in self._field_list_by_id:
                            parameters[pidx] = self._field_list_by_id[lidx]
                        else:
                            raise BMV2AIRError, 'could not find field list by id: %s'%lidx
                    
                    impl.append('%s(%s);'%(op_name, ', '.join(parameters))) 

                acty['implementation'] = implementation('\n'.join(impl))
            
            if act['runtime_data']:
                acty['parameter_list'] = [{p['name']: p['bitwidth']} for p in act['runtime_data']]

    def find_in_dictlist(self, dl, key, value):
        for d in dl:
            if key in d and d[key] == value:
                return d
        return None

    def traverse_flow(self, pipeline):
        known_states = set()
        def recurse_flows(state, dg_flows):
            cond, name, next = resolve_name(state)

            if name in known_states:
                return
            else:
                known_states.add(name)

            if cond is None:
                return
            elif cond:
                next_false = self.as_scoped_name(next[0], pipeline['name']) \
                    if next[0] is not None else 'exit_control_flow'
                next_true = self.as_scoped_name(next[1], pipeline['name']) \
                    if next[1] is not None else 'exit_control_flow'
                dg_flows.append({
                    'src': name,
                    'dest': next_false,
                    'cond': 'condition = false',
                })
                dg_flows.append({
                    'src': name,
                    'dest': next_true,
                    'cond': 'condition = true',
                })
                recurse_flows(next_false, dg_flows)
                recurse_flows(next_true, dg_flows)
            else:
                for ntact, nttbl in next:
                    if len(next) == 1:
                        ntact = 'always'
                    else:
                        ntact = REWRITE_ACTS.get(ntact, self.as_scoped_name(ntact, pipeline['name']))
                    next_tbl = self.as_scoped_name(nttbl, pipeline['name']) if nttbl is not None else 'exit_control_flow'
                    if '::' in ntact:
                        ntact = '"%s"'%ntact
                    dg_flows.append({
                        'src': name,
                        'dest': next_tbl,
                        'cond': 'action = %s'%ntact,
                    })
                    recurse_flows(nttbl, dg_flows)
                    
        def resolve_name(name):
            if name is None:
                return None, None, []

            if '::' in name:
                name = name.split('::')[-1]
            
            sname = self.as_scoped_name(name, pipeline['name'])

            if name == 'exit_control_flow':
                return False, sname, []
            
            if name in self._condition_renames or name in self._conditional_exits['%s_conditionals'%pipeline['name']]:
                if name in self._condition_renames:
                    new_name = self._condition_renames[name]
                else:
                    new_name = sname
                cond_true = self._conditional_exits['%s_conditionals'%pipeline['name']][new_name][True]
                cond_true = self._condition_renames.get(cond_true, cond_true)
                cond_false = self._conditional_exits['%s_conditionals'%pipeline['name']][new_name][False]
                cond_false = self._condition_renames.get(cond_false, cond_false)
                return True, new_name, [cond_false, cond_true]
            
            elif sname in self.yml['tables']:
                tbl = self.find_in_dictlist(pipeline['tables'], 'name', name)
                utables = set()
                next = []
                # check if all actions share a single table
                all_tables = tbl['next_tables'].values()
                if tbl['base_default_next'] is not None:
                    all_tables.append(tbl['base_default_next'])
                if len(set(all_tables)) == 1:
                    nttbl = self._condition_renames.get(tbl['base_default_next'], tbl['base_default_next'])
                    next.append( ('always', nttbl) )
                else:
                    for ntact, nttbl in tbl['next_tables'].items():
                        if  ntact == 'NoAction':
                            continue
                        if (ntact, nttbl) in utables:
                            continue
                        else:
                            utables.add((ntact, nttbl))
                        nttbl = self._condition_renames.get(nttbl, nttbl)
                        next.append( (ntact, nttbl) )

                    # do not add default for hit/miss
                    if set(tbl['next_tables'].keys()) != set(['__HIT__', '__MISS__']):
                        nttbl = self._condition_renames.get(tbl['base_default_next'], tbl['base_default_next'])
                        next.append( ('default', nttbl) )
                    
                return False, sname, next
            else:
                raise BMV2AIRError, 'invalid name: %s'%name
            
        dg_flows = []
        recurse_flows(pipeline['init_table'], dg_flows)
        return resolve_name(pipeline['init_table'])[1], dg_flows
            
    def process_pipelines(self, data):
        def get_action_entry_parameters(act_yml, action_data):
            parameters = {}
            if 'parameter_list' in act_yml:
                for ad, prm in zip(action_data, act_yml['parameter_list']):
                    name = prm.keys()[0]
                    parameters[name] = ad
            return parameters

        def get_match_info(key):
            target = [k.replace('.', '@') for k in key['target']]
            extra_info = []
            if target[-1] == '$valid$' and key['match_type'] == 'exact':
                scope = target[0]
                if scope in self._scopes['header']:
                    scope = self._scopes['header'][scope]
                return scope, 'valid', extra_info
            else:
                if target[0] in self._scopes['header']:
                    target[0] = self._scopes['header'][target[0]]
                if 'mask' in key and key['match_type'] == 'exact' and key['mask'] is not None:
                    extra_info.append('mask %s'%key['mask'])
                return '.'.join(target), key['match_type'], extra_info
        
        # tables
        for pl in data['pipelines']:
            for tbl in pl['tables']:
                max_entries = tbl['max_size']
                if 'default_entry' in tbl:
                    max_entries += 1
                if 'source_info' in tbl:
                    sfn = tbl['source_info']['filename']
                    sln = tbl['source_info']['line']
                else:
                    sfn = ''
                    sln = 1
                allowed_actions = []
                for act_id in tbl['action_ids']:
                    act_name, act_yml = self._actions_by_id[act_id]
                    if act_name == 'NoAction':
                        continue
                    allowed_actions.append(self.as_scoped_name(act_name, pl['name']))
                    
                sname = self.as_scoped_name(tbl['name'], pl['name'])
                self.yml['tables'][sname] = tbly = {
                    'type': 'table',
                    'max_entries': max_entries,
                    'src_filename': sfn,
                    'src_lineno': sln,
                    'allowed_actions': allowed_actions,
                }
                action_entry_const = False
                if 'default_entry' in tbl:
                    act_name, act_yml = self._actions_by_id[tbl['default_entry']['action_id']]
                    if act_name != 'NoAction':
                        parameters = get_action_entry_parameters(act_yml, tbl['default_entry']['action_data'])
                        tbly['default_entry'] = {
                            'action': self.as_scoped_name(act_name, pl['name']),
                            'const': tbl['default_entry']['action_const'],
                        }
                        action_entry_const = tbl['default_entry']['action_entry_const']
                        if parameters:
                            tbly['default_entry']['parameters'] = parameters
                
                if 'entries' in tbl:
                    entries = tbl['entries']
                    tbly['entries'] = entriesy = []
                    
                    for entry in entries:
                        ai = entry['action_entry']['action_id']
                        act_name, act_yml = self._actions_by_id[ai]
                        scoped_act_name = self.as_scoped_name(act_name, pl['name'])
                        parameters = get_action_entry_parameters(act_yml, 
                            entry['action_entry']['action_data'])
                        matches = {}
                        for key, match_key in zip(tbl['key'], entry['match_key']):
                            target, match_type, extra_info = get_match_info(key)
                            assert match_type == match_key['match_type']
                            if match_type in ('exact', 'lpm', 'ternary'):
                                matches[target] = {'value': match_key['key']}
                            elif match_type == 'range':
                                matches[target] = {'value': match_key['start'],
                                                   'rangeto': match_key['end']}
                            if match_type == 'lpm' and 'prefix_length' in match_key:
                                matches[target]['prefix'] = match_key['prefix_length']
                            # XXX can const entry exact match have a mask ?
                            if match_type in ('ternary', 'exact') and 'mask' in match_key:
                                matches[target]['mask'] = match_key['mask']
                            
                        entriesy.append({
                            'actiondata': {
                                'action': scoped_act_name,
                                'parameters': parameters,
                            },
                            'const': True,
                            'matches': matches,
                            'priority': entry['priority'],
                        })

                self.source_files.add(sfn)
                if tbl['type'] in ('simple', 'indirect_ws', 'indirect'):
                    if tbl['match_type'] in ('exact', 'lpm', 'range', 'ternary'):
                        for key in tbl['key']:
                            if 'match_on' not in tbly:
                                tbly['match_on'] = {}
                            target, match_type, extra_info = get_match_info(key)
                            tbly['match_on'][target] = ', '.join([match_type] + extra_info)
  
                    else:
                        raise BMV2AIRError, 'unhandled match type: %s'%tbl['match_type']
                else:
                    raise BMV2AIRError, 'unhandled table type: %s'%tbl['type']

            if pl['name'] in ('ingress', 'egress'):
                self.process_conditionals(pl['name'], pl['conditionals'])

                init_table, flow_transitions = self.traverse_flow(pl)
                self._flow_graphs[pl['name']]['transitions'] = flow_transitions

                dg_flows = '\n'.join(['    "%(src)s" -> "%(dest)s" [%(cond)s]'%f for f in flow_transitions])
                
                if init_table is not None:
                    self.yml['%s_control_flow'%pl['name']]['%s_flow'%pl['name']] = {
                        'type': 'control_flow',
                        'doc': 'control flow for %s'%pl['name'],
                        'format': 'dot',
                        'start_state': init_table,
                        'implementation': implementation('digraph {\n%s\n}'%dg_flows),
                    }

    def process_conditionals(self, pipeline, conditionals):
        for cond in conditionals:
            # rename to p42air standard
            bmvname = cond['name']
            if bmvname not in self._condition_renames:
                self._condition_renames[bmvname] = '_condition_%d'%len(self._condition_renames)
            name = self._condition_renames[bmvname]    
            condition = self.flatten_typed_value(cond['expression'], [], in_expr=True)
            self.yml['%s_conditionals'%pipeline][name] = {
                'type': 'conditional',
                'format': 'bracketed_expr',
                'condition': condition,
                'src_filename': cond.get('source_info', {'filename': ''})['filename'],
                'src_lineno': cond.get('source_info', {'line': 1})['line'],
            }
            self._conditional_exits['%s_conditionals'%pipeline][name] = {
                True: cond['true_next'],
                False: cond['false_next'],
            }
            self._flow_graphs[pipeline]['conditionals'][name] = {'condition': condition}

    def process_headers(self, data):
        for header, hdr in self._headers.items():
            if header in self._scopes['header']:
                header = self._scopes['header'][header]
            self.yml['headers'][header] = hdr

    def process_extern_functions(self, data):
        used_names = {}
        if 'extern_function_instances' in data:
            for ef in data['extern_function_instances']:
                name_count = used_names.setdefault(ef['name'], 0)
                ef_name = '%s__%d'%(ef['name'], name_count)
                used_names[ef['name']] += 1
                self.yml['external_functions'][ef_name] = {
                    'name': ef['name'],
                    'type': 'external_action',
                }

    def process_deparsers(self, data):
        for deparser in data['deparsers']:
            self.yml['deparsers'][deparser['name']] = depy = {
                'type': 'deparser',
                'order': [hdr.replace('.', '@') for hdr in deparser['order']],
            }

    def process_layout(self, data):
        self.yml['processor_layout']['layout'] = ply = {
            'type': 'processor_layout',
            'format': 'list',
            'implementation': [],
        }
        if self.yml['parsers']:
            ply['implementation'].extend(self.yml['parsers'].keys())
        if 'ingress_flow' in self.yml['ingress_control_flow']:
            ply['implementation'].append('ingress')
        if 'egress_flow' in self.yml['egress_control_flow']:
            ply['implementation'].append('egress')

    def process_source_info(self, data):
        self.yml['source_info']['source_info'] = siy = {
            'type': 'source_info',
            'date': datetime.datetime.utcnow().strftime("%Y/%m/%d %H:%M:%S"),
            'source_files': list(self.source_files),
            'output_file': self.output_file,
            'p4_version': self.p4_version,
        }
    
    def generate_yml(self):
        f = open(self.output_file, 'w')

        section_block_line = '##########################################'
        label_fmt = '%%-%ds'%(len(section_block_line)-3)
        section_block_fmt = '%s\n# %s#\n%s\n\n'%(section_block_line, label_fmt, section_block_line)
        
        for name, label in YAML_SECTIONS:
            if self.yml[name]:
                f.write(section_block_fmt%label)
                for key in sorted(self.yml[name]):
                    yaml.safe_dump({key: self.yml[name][key]}, f, indent=4, default_flow_style=False)
                    f.write('\n')
                f.write('\n')

        
def bmv2air(bmv2json, outputfile, p4version, options, validatefile=None):
    d = json.load(open(bmv2json))
    br = BMV2Reader(d, outputfile, p4version)
    br.generate_yml()

    if 'parse_graph' in options:
        from graphs import parse_graph
        ctlflow_data = (br._flow_graphs['ingress'], br._flow_graphs['egress'], {})
        parse_graph(ctlflow_data, br._parse_graph_transitions, options['parse_graph'])

    if 'ingress_graph' in options:
        from graphs import ctlflow_graph
        ctlflow_graph(br._flow_graphs['ingress'], options['ingress_graph'])

    if 'egress_graph' in options:
        from graphs import ctlflow_graph
        ctlflow_graph(br._flow_graphs['egress'], options['egress_graph'])

    if validatefile is not None:
        src = yaml.safe_load(open(validatefile))
        dst = yaml.safe_load(open(outputfile))
        report = []
        compare_yml(src, dst, '', report)
        if report:
            print 'yml differences:'
            for rl in report:
                print rl


def compare_yml(yml1, yml2, ymlpath, report):
    if type(yml1) != type(yml2):
        report.append('yml type mismatch at %s'%ymlpath)
        return

    if ymlpath.endswith('/source_info'):
        return
    
    if isinstance(yml1, dict):
        for k, v in yml1.iteritems():
            if k not in yml2:
                report.append('key "%s" missing in dst at %s'%(k, ymlpath))
            else:
                compare_yml(v, yml2[k], '%s/%s'%(ymlpath, k), report)
    
    elif isinstance(yml1, list):
        for idx, i in enumerate(yml1):
            if idx < len(yml2):
                compare_yml(i, yml2[idx], '%s/%d'%(ymlpath, idx), report)
            else:
                report.append('idx %d missing from dst at %s'%(idx, ymlpath))
    
    else:
        if ymlpath.endswith('/implementation'):
            if yml1.strip().startswith('digraph'):
                dg1 = yml1.strip().split()
                dg2 = yml2.strip().split()
                # ignore exit node name differences
                for didx in range(len(dg1)):
                    if didx < len(dg2) and dg1[didx] != dg2[didx] and dg1[didx] != 'exit':
                        report.append('yml value mismatch %s != %s at %s [%s]'%(yml1, yml2, ymlpath, ' '.join(dg1[didx-1:didx+2])))
                        break
            else:
                ops1 = yml1.split('\n')
                ops2 = yml2.split('\n')
                for oidx in range(len(ops1)):
                    if oidx < len(ops2) and ops1[oidx] != ops2[oidx]:
                        report.append('yml value mismatch %s != %s at %s'%(ops1[oidx], ops2[oidx], ymlpath))
                        break
        elif ymlpath.endswith('/src_filename') or ymlpath.endswith('/src_lineno') or ymlpath.endswith('/date'):
            # skip for now
            return
        elif yml1 != yml2:
            report.append('yml value mismatch %r != %r at %s'%(yml1, yml2, ymlpath))

def main():
    parser = argparse.ArgumentParser(
        description=DESCRIPTION,
        epilog='Copyright (C) 2017 Netronome Systems, Inc.  All rights reserved.')
    parser.add_argument('--version', action='version', version=VERSION)
    parser.add_argument('bmv2json', type=str, 
                        help='BMV2 json file')
    
    parser.add_argument('-o', dest='outfilename', type=str, default="air.yml", help="output AIR filename")
    parser.add_argument('-c', dest='validatefilename', type=str, default=None, help="validation AIR filename")
    
    parser.add_argument('-p', dest='parse_graph', type=str, default=None, help="parse graph output file")
    parser.add_argument('-i', dest='ingress_graph', type=str, default=None, help="ingress graph output file")
    parser.add_argument('-e', dest='egress_graph', type=str, default=None, help="egress graph output file")
    
    args = parser.parse_args()
    options = {}
    if args.parse_graph is not None:
        options['parse_graph'] = args.parse_graph
    if args.ingress_graph is not None:
        options['ingress_graph'] = args.ingress_graph
    if args.egress_graph is not None:
        options['egress_graph'] = args.egress_graph
 
    try:
        bmv2air(args.bmv2json, args.outfilename, options, args.validatefilename)

    except BMV2AIRError, err:
        print >> sys.stderr, "error: %s"%str(err)
        sys.exit(1)        

    except Exception, err:    
        print >> sys.stderr, "unhandled error: %s"%str(err)
        traceback.print_exc()
        sys.exit(1)         
        
if __name__ == '__main__':
    main()

