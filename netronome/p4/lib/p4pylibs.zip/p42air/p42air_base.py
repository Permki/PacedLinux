class P42AIRBaseError(Exception):
    pass

