import os

import pydot

COND_PADMAX = 24
DIGRAPH_TEMPLATE = '''digraph {
    graph [fontname = "Courier New", fontsize = "12"];
    node  [fontname = "Courier New", fontsize = "12"];
    edge  [fontname = "Courier New", fontsize = "12"];
%s
}
'''

def pad_conditional(label, condition):
    # we pad out conditional so they can be sustituted with the
    # contion in the display engine
    constr = "if (" + condition + ")"
    padlen = min(COND_PADMAX, len(constr))
    return label.ljust(padlen)

def gen_display_pydot(flow):
    conditionals = flow['conditionals']
    transitions = flow['transitions']

    display_pydot_string = ""
    for t in transitions:
        nodes = [t['src'], t['dest']]
        for idx, n in enumerate(nodes):
            if n not in conditionals:
                continue
            
            nodes[idx] = pad_conditional(nodes[idx], conditionals[n]['condition'])
        
        cond = t['cond']
        args = cond.split('=', 1)
        if len(args) > 1:
            # now args[0] will always have what is behind the first =
            cond = args[1]
        else:
            cond = args[0]

        # only allow a subset of labels, otherwise things get ugly fast
        allowed_labels = ["hit", "miss", "true", "false", "default"]

        if cond.strip() not in allowed_labels:
            cond = ""
        else:
            cond = "label = " + cond.strip()

        display_pydot_string += '    "%s" -> "%s" [%s]\n' % (
                                nodes[0], nodes[1], cond)

    return DIGRAPH_TEMPLATE % str(display_pydot_string)

def ctlflow_graph(flow, graph):
    if os.path.isfile(graph):
        os.remove(graph)
    if len(flow['transitions']) != 0:
        g = pydot.graph_from_dot_data(gen_display_pydot(flow))
        p = os.path.dirname(graph)
        if p and not os.path.exists(p):
            os.makedirs(p)
        g.write_svg(graph)

def parse_graph(ctlflow_data, transitions, parse_graph):
    # build up the display dot
    (ingress_flow, egress_flow, air_tables) = ctlflow_data
    in_conditionals = ingress_flow['conditionals']
    eg_conditionals = egress_flow['conditionals']
    display_dot_string = ""
    for t in transitions:
        dest = t['dest']
        cond = None
        # check if the node is a conditional, in which case we have to pad them
        # to support substituting a portion of the action condition
        if dest in in_conditionals:
            cond = in_conditionals[dest]
        if dest in eg_conditionals:
            cond = eg_conditionals[dest]
        if cond:
            dest = pad_conditional(dest, cond['condition'])
            
        if t == transitions[-1]:
            display_dot_string += '    "%s" [shape = box];\n'%dest
        display_dot_string += '    %s -> "%s" ' %(t['src'], dest)
        label = ""
        display_dot_string += '[%s]\n' % (label)

    g = pydot.graph_from_dot_data(DIGRAPH_TEMPLATE % str(display_dot_string))
    if os.path.isfile(parse_graph):
        os.remove(parse_graph)
    p = os.path.dirname(parse_graph)
    if p and not os.path.exists(p):
        os.makedirs(p)
    g.write_svg(parse_graph)
