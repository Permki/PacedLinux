#!/usr/bin/python
import argparse
import os
import sys
import collections
import traceback

import p42air_base

import __version__


def p42air(options, split, p4_source_files, yml_output_filename, 
           p4_version='1.0', p4_compiler='hlir', p4_defines=[], p4_includes=[],
           sdk_dir_for_std_includes=None, verbose=False):

    if p4_compiler == 'p4c-nfp':
        import p4c, bmv2air

        assert len(p4_source_files) == 1, 'single p4 source file expected'
        assert not split, 'splitting yml is not supported'
        assert 'custom_primitives' not in options, 'p4c does not support custom primitives'

        assert p4_version != '1.1', 'p4c does not support language spec 1.1'

        # add include paths
        if sdk_dir_for_std_includes is not None:
            p4_incl_version = '1.0' if p4_version == '14' else p4_version

            netro_incl_path = os.path.join(sdk_dir_for_std_includes, 'p4', 'include', p4_incl_version, 'target')
            p4_includes = p4_includes[:] + [netro_incl_path]

            p4_incl_subdir = 'p4include' if p4_version == '16' else 'p4_lib/p4_14include'
            p4_std_incl_path = os.path.join(sdk_dir_for_std_includes, 'p4', 'include', p4_incl_version, p4_incl_subdir).replace('\\', '/')
            # XXX warn if env vars are already set?
            if 'P4C_16_INCLUDE_PATH_OVERRIDE' in os.environ:
                os.environ['P4C_16_INCLUDE_PATH'] = os.environ['P4C_16_INCLUDE_PATH_OVERRIDE']
            else:
                os.environ['P4C_16_INCLUDE_PATH'] = p4_std_incl_path
            if 'P4C_14_INCLUDE_PATH_OVERRIDE' in os.environ:
                os.environ['P4C_14_INCLUDE_PATH'] = os.environ['P4C_14_INCLUDE_PATH_OVERRIDE']
            else:
                if p4_version != '16':
                    os.environ['P4C_14_INCLUDE_PATH'] = p4_std_incl_path
                
        if p4_version == '1.0':
            p4_version = '14'

        p4_includes = [pi.replace('\\', '/') for pi in p4_includes]

        retcode, stdout, stderr = p4c.p4c(p4_source_files[0], p4_version, yml_output_filename, 
            p4_includes, p4_defines, verbosity=int(verbose))
        sys.stdout.write(stdout)
        sys.stderr.write(stderr)
        if retcode != 0:
            raise p4c.P4CError, 'Error during P4 compilation'

        bmv2_json = '%s.bmv2.json'%os.path.splitext(yml_output_filename)[0]
        bmv2air.bmv2air(bmv2_json, yml_output_filename, p4_version, options)
        
    elif p4_compiler == 'hlir':
        assert p4_version != '16', 'hlir does not support language version 16'
        if p4_version == '14':
            p4_version = '1.0'
            
        import p4_hlir_versions as p4hv
        p4hv.select_version(p4_version)
        
        import actions
        import stateful
        import hdrs
        import parse
        import ctlflow
        import srcinfo
        import p42air_common

        # add include paths
        if sdk_dir_for_std_includes is not None:
            p4_includes = p4_includes[:] + [os.path.join(sdk_dir_for_std_includes, 
                'p4', 'include', p4_version, 'p4_lib', 'target')]
        
        # load up the p4 python runtime IR
        custom_primitives = options['custom_primitives'] if 'custom_primitives' in options else None
        primatives_package = '%s.frontend'%p4hv.p4_hlir.__name__
            
        p4data = p4hv.p4_hlir.main.HLIR(custom_primitives, primatives_package)
    
        for p4f in p4_source_files:
            p4data.add_src_files(p4f)
    
        # add custom standard metadata format
        smd = collections.OrderedDict() 
        smd["ingress_port"]           = 10 # port; no channel
        smd["packet_length"]          = 14 # 16k max
        smd["egress_spec"]            = 16 # port + chan
        smd["egress_port"]            = 16 # port + chan
        smd["egress_instance"]        = 10 # max 1k multicast
        smd["instance_type"]          = 4  # eight valid values
        smd["clone_spec" ]            = 32 # opaque identifier
        smd["parser_error_location"]  = 8  # parse state
        smd["parser_status" ]         = 3  # parsing error
    
        if p4data.set_standard_metadata(smd) < 0:
            raise p42air_common.P42AIRError("Failed to add custom standard metadata")
    
        if p4_defines:
            p4data.add_preprocessor_args(*['-D%s'%pd for pd in p4_defines])
        if p4_includes:
            p4data.add_preprocessor_args(*['-I%s'%pi for pi in p4_includes])
        
        if p4data.build() == False:
            raise p42air_common.P42AIRError("Failed to build P4 design")
    
        entity_namer = p42air_common.entity_namer()
    
        # generate air data structures for the various stages
        hdrs_data = hdrs.hdrs_gen(p4data, entity_namer)
        ctlflow_data = ctlflow.ctlflow_gen(p4data, entity_namer, options=options)
        stateful_data = stateful.stateful_gen(p4data, entity_namer, ctlflow_data, options=options)
        parse_data = parse.parse_gen(p4data, entity_namer, ctlflow_data, options=options)
        actions_data = actions.actions_gen(p4data, entity_namer, ctlflow_data, stateful_data)
        srcinfo_data = srcinfo.srcinfo_gen(p4data, yml_output_filename)
    
        # stage 2 compilation
        ctlflow.ctlflow_gen_stage2(ctlflow_data, actions_data)
        
        # write out AIR yaml file(s)
        
        types = ['headers', 'stateful', 'parser', 'actions', 'control', 'srcinfo']
        
        # store open file handle(s)
        outfile_h = {}
        # stores references to open file handles per output type
        outfiles = {}
    
        p = os.path.dirname(yml_output_filename)
        if p and not os.path.exists(p):
            os.makedirs(p)

        if not split:
            outfile_h['all'] = open(yml_output_filename, "w+")
            for t in types:
                outfiles[t] = outfile_h['all']
        else:
            path_split = os.path.splitext(yml_output_filename)
            for t in types:
                outfile_h[t] = open(path_split[0] + "_" + t + path_split[1], "w+")
                outfiles[t] = outfile_h[t]
        
        hdrs.hdrs_output(outfiles['headers'], hdrs_data)
        stateful.stateful_output(outfiles['stateful'], stateful_data)
        parse.parse_output(outfiles['parser'], parse_data, ctlflow_data, options=options)
        actions.actions_output(outfiles['actions'], actions_data, options=options)
        ctlflow.ctlflow_output(outfiles['control'], ctlflow_data, actions_data)
        srcinfo.srcinfo_output(outfiles['srcinfo'], srcinfo_data)
        
        # close all open file handles
        for f in outfile_h:
            outfile_h[f].close()
    
    else:
       raise p42air_base.P42AIRBaseError, 'unsupported p4 compiler: %s'%p4_compiler

    if 'interactive' in options:
        import IPython
        IPython.embed()


def main():
    parser = argparse.ArgumentParser(
        description=__version__.DESCRIPTION,
        epilog='Copyright (C) 2016, 2017 Netronome Systems, Inc.  All rights reserved.')
    parser.add_argument('--version', action='version', version=__version__.VERSION)
    parser.add_argument('p4_source_files', metavar='p4src',
                        type=str, nargs='+',
                        help='P4 source file')
    
    parser.add_argument('-o', dest='outfilename', type=str, default="air.yml", help="output AIR filename")
    parser.add_argument('-p', dest='parse_graph', type=str, default=None, help="parse graph output file")
    parser.add_argument('-i', dest='ingress_graph', type=str, default=None, help="ingress graph output file")
    parser.add_argument('-e', dest='egress_graph', type=str, default=None, help="egress graph output file")
    parser.add_argument('-c', dest='custom_primitives', type=str, default=None, help="custom primitives JSON")
    parser.add_argument('-v', dest='verbose', action='store_true', default=False, help="verbose output")
    parser.add_argument('--source_info', action="store_true",
                        help="include source filename and line number in certain objects")
    parser.add_argument('--split', action="store_true",
                        help="split AIR output into multiple files")
    parser.add_argument('-I', dest='p4_includes', type=str, default=[], action='append',
                        help="p4 preprocessor include paths")
    parser.add_argument('-D', dest='p4_defines', type=str, default=[], action='append',
                        help="p4 preprocessor defines")
    parser.add_argument('--p4-version', dest='p4_version', action="store", default='1.0', 
                        choices=('1.0', '1.1', '14', '16'),
                        help="select p4 language version")
    parser.add_argument('--p4-compiler', dest='p4_compiler', action="store", default=None, 
                        choices=('hlir', 'p4c-nfp'),
                        help="select p4 compiler")
    parser.add_argument('--std-includes', dest='std_includes', action='store_true', default=True, 
                        help="add standard p4/nfp include paths to the build")
    parser.add_argument('--no-std-includes', dest='std_includes', action='store_false', default=True, 
                        help="do not add standard p4/nfp include paths to the build")
                        
    if not hasattr(sys, 'frozen'):
        parser.add_argument('--interactive', action="store_true",
                            help="initiate an interactive shell after building")
        
    args = parser.parse_args()
    
    if args.p4_compiler == None:
        if args.p4_version == '16':
            p4_compiler = 'p4c-nfp'
        else:
            p4_compiler = 'hlir'
    else:
        p4_compiler = args.p4_compiler

    options = {}
    if args.source_info == True:
        options['src_info'] = True
    if not hasattr(sys, 'frozen') and args.interactive == True:
        options['interactive'] = True
    if args.parse_graph != None:
        options['parse_graph'] = args.parse_graph
    if args.ingress_graph != None:
        options['ingress_graph'] = args.ingress_graph
    if args.egress_graph != None:
        options['egress_graph'] = args.egress_graph
    if args.custom_primitives != None:
        options['custom_primitives'] = args.custom_primitives

    sdk_dir_for_std_includes = None
    if args.std_includes:
        if 'SDKDIR' not in os.environ:
            sdk_dir_found = False
            # try to find the toolchain from relative paths when running as a binary
            if hasattr(sys, 'frozen'):
                sdk_dir = os.path.normpath(os.path.abspath(
                    os.path.join(os.path.dirname(sys.executable), '..', '..')))
                if os.path.isdir(os.path.join(sdk_dir, 'p4', 'include')):
                    sdk_dir_found = True
                    sdk_dir_for_std_includes = sdk_dir
            # try to find the toolchain from relative paths when running as source from expected location
            else:    
                sdk_dir = os.path.normpath(os.path.abspath(
                    os.path.join(os.path.dirname(__file__), '..')))
                if os.path.isdir(os.path.join(sdk_dir, 'p4', 'include')):
                    sdk_dir_found = True
                    sdk_dir_for_std_includes = sdk_dir
                
            if not sdk_dir_found:
                print >> sys.stderr, "error: The SDKDIR environment variable is not "\
                                     "set, this is required for standard p4 include paths."
                sys.exit(1)        
        else:
            sdk_dir_for_std_includes = os.environ['SDKDIR']

    try:
        p42air(options, args.split, args.p4_source_files, args.outfilename, 
               args.p4_version, p4_compiler, args.p4_defines, args.p4_includes,
               sdk_dir_for_std_includes, args.verbose)

    except p42air_base.P42AIRBaseError, err:
        print >> sys.stderr, "error: %s"%str(err)
        sys.exit(1)        

    except Exception, err:    
        print >> sys.stderr, "unhandled error: %s"%str(err)
        traceback.print_exc()
        sys.exit(1)        
    
if __name__ == '__main__':
    main()
