import sys

import collections

from p42air_common import I, FOUT, expand_expression, P42AIRError

def stateful_gen(p4data, entity_namer, ctlflow_data, options={}):

    stateful_data = {}
    stateful_data['registers'] = collections.OrderedDict()
    stateful_data['meters'] = collections.OrderedDict()

    #
    # Registers
    #
    for rname, r in p4data.p4_registers.items():
        robj = {}
        try:
            entity_namer.register_name(rname,
                                       r.filename,
                                       r.lineno);
        except:
            robj['unique_name'] = entity_namer.get_unique_name(rname)
            entity_namer.register_name(robj['unique_name'],
                                       r.filename,
                                       r.lineno);


        robj['name'] = r.name
        robj['doc'] = r.doc
        robj['lineno'] = r.lineno
        robj['filename'] = r.filename

        if r.instance_count == None:
            robj['instance_count'] = 1
        else:
            robj['instance_count'] = r.instance_count

        robj['fields'] = collections.OrderedDict()
        if r.width == None: # field layout
            for k, v in r.layout.layout.items():
                robj['fields'][k] = v;
        else:
            robj['fields']['value'] = r.width;

        if type(r.binding) == tuple:
            robj['class'] = r.binding[0].value
            robj['table'] = r.binding[1].name
        else:
            robj['class'] = 'global'

        robj['pragmas'] = []

        for pragma, pragma_obj in r._parsed_pragmas.items():
            if pragma != 'netro':
                continue
            if 'reglocked' in pragma_obj.keys():
                robj['pragmas'].append("netro reglocked")

        stateful_data['registers'][r.name] = robj


    #
    # Meters
    #

    for mname, m in p4data.p4_meters.items():
        mobj = {}
        try:
            entity_namer.register_name(mname,
                                       m.filename,
                                       m.lineno);
        except:
            mobj['unique_name'] = entity_namer.get_unique_name(mname)
            entity_namer.register_name(mobj['unique_name'],
                                       m.filename,
                                       m.lineno);

        mobj['name'] = m.name
        mobj['doc'] = m.doc
        mobj['lineno'] = m.lineno
        mobj['filename'] = m.filename
        mobj['pragmas'] = []
        mobj['result'] = m.result

        if m.instance_count == None:
            mobj['instance_count'] = 1
        else:
            mobj['instance_count'] = m.instance_count

        mobj['type'] = m.type

        if type(m.binding) == tuple:
            mobj['class'] = m.binding[0].value
            mobj['table'] = m.binding[1].name
        else:
            mobj['class'] = 'global'

        for pragma, pragma_obj in m._parsed_pragmas.items():
            if pragma != 'netro':
                continue
            if 'meter_drop_red' in pragma_obj.keys():
                mobj['pragmas'].append("netro meter_drop_red")

        stateful_data['meters'][mname] = mobj


    #
    # Counters
    #

    for cname in p4data.p4_counters:
        cobj = {}
        c = p4data.p4_counters[cname]

        try:
            entity_namer.register_name(cname,
                                       c.filename,
                                       c.lineno);
        except:
            cobj['unique_name'] = entity_namer.get_unique_name(cname)
            entity_namer.register_name(cobj['unique_name'],
                                       c.filename,
                                       c.lineno);

        if c.min_width > 64:
            raise P42AIRError("counter %s has min_width " \
                              "greater than the supported max of 64\n" %
                              (c.name) )


        cobj['name'] = c.name
        cobj['doc'] = c.doc
        cobj['lineno'] = c.lineno
        cobj['filename'] = c.filename
        cobj['pragmas'] = []

        cobj['type'] = c.type.value

        if c.instance_count == None:
            cobj['instance_count'] = 1
        else:
            cobj['instance_count'] = c.instance_count

        types = []
        if "packet" in c.type.value:
            types.append("packets")
        if "byte" in c.type.value:
            types.append("bytes")

        cobj['fields'] = collections.OrderedDict()
        cobj['counts'] = collections.OrderedDict()
        for t in types:
            # TODO: make the size of the counter tunable
            #       64 bits may be more than people want
            fld = "value_" + t
            cobj['fields'][fld] = 64 # all counters 64-bit

            cobj['counts'][t] = fld

        if type(c.binding) == tuple:
            cobj['class'] = c.binding[0].value
            cobj['table'] = c.binding[1].name
        else:
            cobj['class'] = 'global'

        stateful_data['registers'][c.name] = cobj

    # here we create direct counters for all tables which support
    # timeouts
    for tbl in ctlflow_data[2]:
        if not tbl['support_timeout']:
            continue

        cobj = {}

        cobj['name'] = '_pif_timeout_cntr_' + tbl['name']
        cobj['lineno'] = ""
        cobj['filename'] = ""
        cobj['pragmas'] = ["hidden", "timeout_counter"]

        cobj['class'] = 'direct'

        cobj['instance_count'] = 1

        cobj['type'] = 'packets'

        cobj['fields'] = collections.OrderedDict()
        cobj['counts'] = collections.OrderedDict()

        fld = "value_packets"
        cobj['fields'][fld] = 64 # all counters 64-bit

        cobj['counts']['packets'] = fld
        cobj['table'] = tbl['name']

        stateful_data['registers'][cobj['name']] = cobj

    return stateful_data

#####################################################
# Output code
#####################################################

def stateful_output(outfile, stateful_data):
    if len(stateful_data['meters']) > 0:
        FOUT(outfile, 0, "##########################################\n");
        FOUT(outfile, 0, "# Meters definitions                     #\n");
        FOUT(outfile, 0, "##########################################\n\n");

        for mtrname,mtr in stateful_data['meters'].items():

            if 'unique_name' in mtr:
                FOUT(outfile, 0, "\"%s\" :\n" %(mtr['unique_name']));
                FOUT(outfile, 1, 'name : "%s"\n' % (mtrname));
            else:
                FOUT(outfile, 0, '"%s" :\n' %(mtrname))

            FOUT(outfile, 1, 'type : meter\n')

            FOUT(outfile, 1, 'class : "%s"\n' % (mtr['class']))

            FOUT(outfile, 1, 'meters : "%s"\n' % (mtr['type']))

            if 'table' in mtr:
                FOUT(outfile, 1, 'table : "%s"\n' % (mtr['table']))
            FOUT(outfile, 1, 'instance_count : %d\n' % (mtr['instance_count']))

            if 'doc' in mtr and mtr['doc']:
                FOUT(outfile, 1, 'doc : "%s"\n' % (mtr['doc']))
            if len(mtr['pragmas']) > 0:
                FOUT(outfile, 1, 'pragmas : \n');
                for p in mtr['pragmas']:
                    FOUT(outfile, 2, '- "%s"\n' % (p))

            FOUT(outfile, 0, "\n")

    if len(stateful_data['registers']) > 0:
        FOUT(outfile, 0, "##########################################\n");
        FOUT(outfile, 0, "# Register definitions                   #\n");
        FOUT(outfile, 0, "##########################################\n\n");

        for regname,reg in stateful_data['registers'].items():
            if 'unique_name' in reg:
                FOUT(outfile, 0, "\"%s\" :\n" %(reg['unique_name']));
                FOUT(outfile, 1, 'name : "%s"\n' % (regname));
            else:
                FOUT(outfile, 0, '"%s" :\n' %(regname))

            FOUT(outfile, 1, 'type : register\n')

            FOUT(outfile, 1, 'class : "%s"\n' % (reg['class']))
            if 'table' in reg:
                FOUT(outfile, 1, 'table : "%s"\n' % (reg['table']))
            FOUT(outfile, 1, 'instance_count : %d\n' % (reg['instance_count']))

            if 'doc' in reg and reg['doc']:
                FOUT(outfile, 1, 'doc : "%s"\n' % (reg['doc']))

            FOUT(outfile, 1, 'fields : \n');
            for f in reg['fields']:
                fld = reg['fields'][f]
                FOUT(outfile, 2, '- "%s" : %d\n' % (f, fld))

            if 'counts' in reg and len(reg['counts']) > 0:
                FOUT(outfile, 1, 'counts : \n');
                for c in reg['counts']:
                    FOUT(outfile, 2, '- "%s" : "%s"\n' % (c, reg['counts'][c]))
            if len(reg['pragmas']) > 0:
                FOUT(outfile, 1, 'pragmas : \n');
                for p in reg['pragmas']:
                    FOUT(outfile, 2, '- "%s"\n' % (p))

            FOUT(outfile, 0, "\n")
