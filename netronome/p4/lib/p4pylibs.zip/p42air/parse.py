import os, sys, copy, collections

import graphs

import p4_hlir_versions as p4hv

from p42air_common import I, FOUT, P42AIRError, expand_expression

def unroll_pragma(pragma_str, pragma_obj):
    pragmas = []
    # unroll all the nested dicts to reform the pragma string
    stack = [(pragma_str, pragma_obj)]
    while len(stack) > 0:
        entry_str, entry_obj = stack.pop()

        if type(entry_obj) != collections.OrderedDict:
            continue

        for k in entry_obj.keys():
            stack.append((entry_str + " " + k, entry_obj[k]))

        if len(entry_obj.keys()) == 0:
            # the end of the tree entry, so lock in the pragma
            pragmas.append(entry_str)
    return pragmas
        

def parse_gen(p4data, entity_namer, ctlflow_data, options = {}):
    ##############################
    # Parse states
    ##############################

    air_exceptions = collections.OrderedDict()

    expressions = collections.OrderedDict()

    (ingress_flow, egress_flow, air_tables) = ctlflow_data

    initial_flow = 'exit_control_flow'

    for pe, peobj in p4data.p4_parser_exceptions.items():
        expression_no = 0
        airpe = { 'name' : pe,
                  'exception' : 'custom',
                  'sets' : [],
                  'action' : 'drop',
                  'doc' : None }

        try:
            entity_namer.register_name(pe,
                                       peobj.filename,
                                       peobj.lineno)
        except:
            airpe['unique_name'] = entity_namer.get_unique_name(pe)
            entity_namer.register_name(airpe['unique_name'],
                                       peobj.filename,
                                       peobj.lineno)

        for set_statement in peobj.set_statements:
            if str(set_statement[0]) != 'set':
                raise P42AIRError("unexpected set_statement type %s " \
                                  "in parser exception %s\n" %
                                  (set_statement[0], pe))

            # set metadata
            fld = set_statement[1].name
            hdr = set_statement[1].instance.name

            if type(set_statement[2]) in [int, long]:
                val = set_statement[2]
            elif type(set_statement[2]) == p4hv.p4_hlir.hlir.p4_headers.p4_field:
                val = "%s.%s" % (set_statement[2].instance.name,
                                 set_statement[2].name)
            elif type(set_statement[2]) == p4hv.p4_hlir.hlir.p4_expressions.p4_expression:
                expression_name = "_expression_%s_%d" % (pe, expression_no)
                expression_no += 1
                expressions[expression_name] = {
                        "expression" : expand_expression(set_statement[2], 64)
                        }
                val = expression_name
            else:
                raise P42AIRError("unexpected set_statement arg type %s " \
                                  "in parser exception %s\n" %
                                  (set_statement[2], pe))

            airpe['sets'].append(["%s.%s" % (hdr, fld), val])
        if type(peobj.return_or_drop) == p4hv.p4_hlir.hlir.p4_tables.p4_conditional_node:
            airpe['action'] = peobj.return_or_drop.name
        elif type(peobj.return_or_drop) == p4hv.p4_hlir.hlir.p4_tables.p4_table:
            airpe['action'] = peobj.return_or_drop.name
        elif str(peobj.return_or_drop) == 'P4_PARSER_DROP':
            airpe['action'] = 'drop'
        else:
            raise P42AIRError("unexpected parser exception %s " \
                              "in parser exception %s\n" %
                              (str(peobj.return_or_drop), pe))

        implicit_exceptions = [
            "p4_pe_index_out_of_bounds",
            "p4_pe_out_of_packet",
            "p4_pe_header_too_long",
            "p4_pe_header_too_short",
            "p4_pe_unhandled_select",
            "p4_pe_checksum",
            "p4_pe_default", ]
        if pe in implicit_exceptions:
            airpe['exception'] = pe.replace('p4_pe_', '')

        air_exceptions[pe] = airpe

    air_parse_states = collections.OrderedDict()

    split_nodes = collections.OrderedDict()

    for ps in p4data.p4_parse_states:
        expression_no = 0
        airps = {} 
        p4ps = p4data.p4_parse_states[ps]

        pragmas = []

        for pragma, pragma_obj in p4ps._parsed_pragmas.items():
            supported_pragmas = ["netro", "header_ordering"]
            if pragma in supported_pragmas:
                pragmas += unroll_pragma(pragma, pragma_obj)

        try:
            entity_namer.register_name(ps,
                                       p4ps.filename,
                                       p4ps.lineno)
        except:
            airps['unique_name'] = entity_namer.get_unique_name(ps)
            entity_namer.register_name(airps['unique_name'],
                                       p4ps.filename,
                                       p4ps.lineno)

        airps['pragmas'] = pragmas
        airps['name'] = ps

        airps['doc'] = p4ps.doc

        if "src_info" in options:
            airps['src_filename'] = os.path.normpath(p4ps.filename)
            airps['src_lineno'] = p4ps.lineno

        #
        # handle the select fields
        #

        airps['select_value'] = []
        for fobj in p4ps.branch_on:
            if type(fobj) not in [p4hv.p4_hlir.hlir.p4_headers.p4_field, tuple]:
                raise P42AIRError("only arrays of field values or current tuples are supported for select_value\n")
                # FIXME: support runtime sets + calls to current(), whatever that means

            if type(fobj) == tuple:
                # handle the current() case
                if len(fobj) != 2:
                    raise P42AIRError("current() tuples must have two entries\n")

                airps['select_value'].append("current(%d,%d)" % (fobj[0], fobj[1]))
                continue

            fld = fobj.name
            hdr = fobj.instance.name

            if "[next]" in hdr:
                # next is rubbish here
                # the transition is based on the last extracted header
                # so lets correct it here
                hdr = hdr.replace("[next]", "[last]")

            airps['select_value'].append("%s.%s" % (hdr, fld))

        #
        # handle the p4 parse call sequences
        #

        airps['extracts'] = []
        airps['sets'] = []

        split = 0

        #for calltype, callobj, callargs in p4ps.call_sequence:
        for call in p4ps.call_sequence:
            if len(call) == 2:
                calltype, callobj = call
                callargs = []
            elif len(call) == 3:
                calltype, callobj, callargs = call
            else:
                raise P42AIRError("unsupported p4 parse call format %s\n" %(str(call)))

            if calltype.value not in ['set', 'extract']:
                raise P42AIRError("unsupported p4 parse call type %s\n" % (calltype.value))

            if calltype.value == 'extract':
                if type(callargs) == list and len(callargs) != 0:
                    raise P42AIRError("further argument for p4 parse calls not supported\n")

                # for now only a single header per node is supported
                # this could probably be a command line option
                if len(airps['extracts']):
                    newairps = copy.deepcopy(airps)

                    # clear sets + header for continued node
                    airps['extracts'] = []
                    airps['sets'] = []


                    # select goes in final node
                    new_node_name = "_" + ps + "_split_%d" % split

                    newairps['select_value'] = []
                    newairps['name'] = new_node_name
                    if type(p4ps.doc) == str:
                        newairps['doc'] = p4ps.doc + "(split %d)" % (split)
                    else:
                        newairps['doc'] = ps + " split %d" % (split)

                    air_parse_states[new_node_name] = newairps
                    if split == 0:
                        split_nodes[ps] = [new_node_name]
                    else:
                        split_nodes[ps].append(new_node_name)
                    split += 1


                if "[next]" in callobj.name:
                    callobj.name = callobj.name.split("[next]")[0]

                airps['extracts'].append(callobj.name)
                continue

            if calltype.value == 'set':
                if type(callargs) == list and len(callargs) != 0:
                    raise P42AIRError("further argument for p4 parse calls not supported\n")

                # set metadata
                fld = callobj.name
                hdr = callobj.instance.name

                if type(callargs) in [int, long]:
                    val = callargs
                elif type(callargs) == p4hv.p4_hlir.hlir.p4_headers.p4_field:
                    hdr_name = callargs.instance.name
                    if callargs.instance.max_index != None:
                        if '[' not in hdr_name:
                            # this is a stack, but hlir doesn't provide an index in latest.field case
                            hdr_name += "[last]"

                    val = "%s.%s" % (hdr_name, callargs.name)
                elif type(callargs) == p4hv.p4_hlir.hlir.p4_expressions.p4_expression:
                    expression_name = "_expression_%s_%d" % (ps, expression_no)
                    expression_no += 1
                    expressions[expression_name] = {
                            "expression" : expand_expression(callargs, 64)
                            }
                    val = expression_name
                else:
                    raise P42AIRError("unexpected set_statement arg type %s " \
                                      "in parse node %s\n" %
                                      (type(callargs), ps))

                airps['sets'].append(["%s.%s" % (hdr, fld), val])
                continue

        air_parse_states[ps] = airps

    ##############################
    # Parse graph
    ##############################

    # p4 graph is not cyclical, so we can happily process nodes in order and add
    # transitions to a list

    # p4 always calls the starting node start
    nodestack = ["start"]
    nodedone = []

    transitions = []

    while len(nodestack) > 0:

        node = nodestack.pop(0)
        nodedone.append(node)

        p4ps = p4data.p4_parse_states[node]

        # if the node is split we insert the split parts here
        if p4ps.name in split_nodes:
            cnt = len(split_nodes[p4ps.name])
            for i in range(cnt):
                transition = {}
                transition['src'] = split_nodes[p4ps.name][i]

                if i == cnt - 1:
                    transition['dest'] = p4ps.name
                else:
                    transition['dest'] = split_nodes[p4ps.name][i + 1]
                transition['value'] = None
                transition['order'] = 0

                transitions.append(transition);

        order = 0
        for bt_val in p4ps.branch_to:
            transition = {}
            transition['src'] = node

            bt_dest_obj = p4ps.branch_to[bt_val]
            if p4ps.branch_to[bt_val] == None:
                # this is the very weird case where the transition
                # is to an empty control flow which was zapped
                bt_dest = initial_flow
            else:
                bt_dest = p4ps.branch_to[bt_val].name

            transition['dest'] = bt_dest
            transition['mask'] = None
            transition['order'] = order

            order += 1

            if type(bt_val) in [int, long]:
                transition['value'] = bt_val
            elif type(bt_val) == tuple and len(bt_val) == 2:
                transition['value'] = bt_val[0]
                transition['mask'] = bt_val[1]
            elif type(bt_val) == p4hv.p4_hlir.hlir.p4_parser.p4_parse_value_set:
                transition['value'] = bt_val.name
            else:
                try:
                    if str(bt_val) == 'P4_DEFAULT':
                        # default case
                        transition['value'] = None
                    else:
                        raise ValueError("")
                except:
                    raise P42AIRError("unsupported p4 parse branch to value %s\n" % (str(bt_val)))

            # transition is to a split node, point it to the first in the split
            if transition['dest'] in split_nodes:
                transition['dest'] = split_nodes[transition['dest']][0]

            transitions.append(transition);

            if bt_dest in nodestack or bt_dest in nodedone:
                continue

            if type(bt_dest_obj) == p4hv.p4_hlir.hlir.p4_parse_state:
                nodestack.append(bt_dest)

    if len(transitions) == 0:
        transitions.append({'src' : 'start', 'dest' : 'exit_control_flow', 'value' : None, 'order' : 0})

    # build up the dot string
    air_dot_string = I(2) + "digraph {\n"
    for t in transitions:
        air_dot_string += I(3) + '%s -> %s ' %(t['src'], t['dest'])
        orderstr = t['order']
        if t['value'] == None:
            valstr = "default"
            maskstr = "none"
        elif type(t['value']) in [int, long]:
            valstr = "0x%x" %(t['value'])
            if t['mask'] == None:
                maskstr = "none"
            else:
                maskstr = "0x%x" %(t['mask'])
        else:
            valstr = t['value']
            mask = None
        air_dot_string += '[value="%s", mask="%s", order="%s"]\n' % (valstr, maskstr, orderstr)

    air_dot_string += I(2) + "}\n"

    air_value_sets = collections.OrderedDict()
    for vsname, vsobj in p4data.p4_parse_value_sets.items():
        ent = {}
        try:
            entity_namer.register_name(vsname,
                                       vsobj.filename,
                                       vsobj.lineno)
        except:
            ent['unique_name'] = entity_namer.get_unique_name(vsname)
            entity_namer.register_name(ent['unique_name'],
                                       vsobj.filename,
                                       vsobj.lineno)
        ent['name'] = vsname
        ent['doc'] = vsobj.doc
        ent['src_lineno'] = vsobj.lineno
        ent['src_filename'] = os.path.normpath(vsobj.filename)
        air_value_sets[vsname] = ent

    parser_data = { "air_parse_states" : air_parse_states,
                    "air_dot_string" : air_dot_string,
                    "transitions" : transitions,
                    "air_exceptions": air_exceptions,
                    "air_value_sets": air_value_sets,
                    "expressions" : expressions}

    return parser_data

#####################################################
# Output code
#####################################################

def parse_output(outfile, gen_data, ctlflow_data, options = {}):
    air_parse_states = gen_data["air_parse_states"] 
    air_dot_string   = gen_data["air_dot_string"]
    transitions      = gen_data["transitions"]
    air_exceptions   = gen_data["air_exceptions"]
    air_value_sets   = gen_data["air_value_sets"]
    expressions      = gen_data["expressions"]

    if len(air_value_sets) > 0:
        FOUT(outfile, 0, "##########################################\n");
        FOUT(outfile, 0, "# Parser Value Sets                      #\n");
        FOUT(outfile, 0, "##########################################\n\n");

    for vsname, vsobj in air_value_sets.items():
        if 'unique_name' in vsobj:
            FOUT(outfile, 0, "\"%s\" :\n" %(vsobj['unique_name']));
            FOUT(outfile, 1, 'name : "%s"\n' % (vsname));
        else:
            FOUT(outfile, 0, '"%s" :\n' %(vsname))

        FOUT(outfile, 1, 'type : value_set\n')

        if vsobj['doc'] != None:
            FOUT(outfile, 1, 'doc : "%s"\n' % (vsobj['doc']))

        if 'src_filename' in vsobj:
            FOUT(outfile, 1, "src_filename : '%s'\n" %(vsobj['src_filename']))

        if 'src_lineno' in vsobj:
            FOUT(outfile, 1, 'src_lineno : %d\n' %(vsobj['src_lineno']))

        FOUT(outfile, 0, '\n')

    if len(expressions) > 0:
        FOUT(outfile, 0, "##########################################\n");
        FOUT(outfile, 0, "# Parser Expressions                     #\n");
        FOUT(outfile, 0, "##########################################\n\n");
        for ename, e in expressions.items():
            # expression are given unique names
            FOUT(outfile, 0, "%s:\n" %(ename));
            FOUT(outfile, 1, "type : expression\n");
            if 'doc' in e and e['doc'] != None:
                FOUT(outfile, 1, 'doc : "%s"\n' % (e['doc']));
            FOUT(outfile, 1, "expression : \"%s\"\n" % (e['expression']));
            FOUT(outfile, 1, 'format : bracketed_expr\n');
            FOUT(outfile, 0, '\n');

    FOUT(outfile, 0, "##########################################\n");
    FOUT(outfile, 0, "# Parse states                           #\n");
    FOUT(outfile, 0, "##########################################\n\n");

    for ps in air_parse_states:
        psd = air_parse_states[ps]
        if 'unique_name' in psd:
            FOUT(outfile, 0, "\"%s\" :\n" %(psd['unique_name']));
            FOUT(outfile, 1, 'name : "%s"\n' % (ps));
        else:
            FOUT(outfile, 0, '\"%s\" :\n' %(ps))

        FOUT(outfile, 1, 'type : parse_state\n')

        if psd['doc'] != None:
            FOUT(outfile, 1, 'doc : "%s"\n' % (psd['doc']))

        if len(psd['sets']) > 0:
            FOUT(outfile, 1, 'sets :\n')
            for sp in psd['sets']:
                sf, sv = sp
                FOUT(outfile, 2, '- "%s" : ' % (sf))
                if type(sv) in [int, long]:
                    FOUT(outfile, 0, '%d\n' % (sv))
                else:
                    FOUT(outfile, 0, '"%s"\n' % (sv))

        if len(psd['extracts']) > 0:
            FOUT(outfile, 1, 'extracts :\n')
            for ef in psd['extracts']:
                FOUT(outfile, 2, '- "%s"\n' % (ef))

        if len(psd['select_value']) > 0:
            FOUT(outfile, 1, 'select_value :\n')
            for sv in psd['select_value']:
                FOUT(outfile, 2, '- "%s"\n' % (sv))

        if len(psd['pragmas']) > 0:
            FOUT(outfile, 1, 'pragmas :\n')
            for pr in psd['pragmas']:
                FOUT(outfile, 2, '- "%s"\n' % (pr))

        if 'src_filename' in psd:
            FOUT(outfile, 1, "src_filename : '%s'\n" %(psd['src_filename']))

        if 'src_lineno' in psd:
            FOUT(outfile, 1, 'src_lineno : %d\n' %(psd['src_lineno']))

        FOUT(outfile, 0, '\n')

    FOUT(outfile, 0, "##########################################\n");
    FOUT(outfile, 0, "# Parser                                 #\n");
    FOUT(outfile, 0, "##########################################\n\n");

    FOUT(outfile, 0, 'parser :\n')
    FOUT(outfile, 1, 'type : parser\n')
    FOUT(outfile, 1, 'format : dot\n')
    FOUT(outfile, 1, 'start_state : \"%s\"\n' %(air_parse_states.keys()[0]))
    FOUT(outfile, 1, 'implementation : >-\n')
    FOUT(outfile, 0, air_dot_string)
    FOUT(outfile, 0, "\n")

    if len(air_exceptions) > 0:
        FOUT(outfile, 0, "##########################################\n");
        FOUT(outfile, 0, "# Parser Exceptions                      #\n");
        FOUT(outfile, 0, "##########################################\n\n");

        for pe, peobj in air_exceptions.items():
            if 'unique_name' in peobj:
                FOUT(outfile, 0, "\"%s\" :\n" %(peobj['unique_name']));
                FOUT(outfile, 1, 'name : "%s"\n' % (pe));
            else:
                FOUT(outfile, 0, '"%s" :\n' %(pe))
            FOUT(outfile, 1, 'type : parser_exception\n')

            if peobj['doc'] != None:
                FOUT(outfile, 1, 'doc : "%s"\n' % (peobj['doc']))

            if len(peobj['sets']) > 0:
                FOUT(outfile, 1, 'sets :\n')
                for sp in peobj['sets']:
                    sf, sv = sp
                    FOUT(outfile, 2, '- "%s" : ' % (sf))
                    if type(sv) in [int, long]:
                        FOUT(outfile, 0, '%d\n' % (sv))
                    else:
                        FOUT(outfile, 0, '"%s"\n' % (sv))

            FOUT(outfile, 1, 'exception :\n')
            FOUT(outfile, 2, '"%s" : "%s"\n' %
                             (peobj['exception'], peobj['action']))

            FOUT(outfile, 0, '\n')

    if "parse_graph" in options:
        graphs.parse_graph(ctlflow_data, transitions, options["parse_graph"])

