
import os, collections, copy

import p4_hlir_versions as p4hv

from p42air_common import I, FOUT, P42AIRError, expand_expression

def actions_gen(p4data, entity_namer, ctlflow_data, stateful_data, options=[]):
    primitives = {}
    air_action_sets = {}
    digests = collections.OrderedDict()
    external_actions = collections.OrderedDict()

    modified_actions = collections.OrderedDict()

    action_expressions = collections.OrderedDict()

    for a in p4data.p4_actions:
        p4aobj = p4data.p4_actions[a]

        acts = {'name' : a, 'pragmas' : []}

        try:
            filename = p4aobj.filename
            lineno = p4aobj.lineno
        except:
            filename = "unknown"
            lineno = -1


        try:
            entity_namer.register_name(a,
                                       filename,
                                       lineno);
        except:
            acts['unique_name'] = entity_namer.get_unique_name(a)
            entity_namer.register_name(acts['unique_name'],
                                       filename,
                                       lineno);


        for pragma, pragma_obj in p4aobj._parsed_pragmas.items():
            if pragma != 'netro':
                continue
            if 'no_lookup_caching' in pragma_obj.keys():
                acts['pragmas'].append("netro no_lookup_caching")

        if p4aobj.__class__.__name__ == "p4_extern_method":
            # note: we do the class string check to support 1.0 too
            extern_type_obj = p4aobj.parent.extern_type

            ext_name = extern_type_obj.name
            ext_pragmas = extern_type_obj._parsed_pragmas

            is_c_extern = False
            name_qualifier = ""

            for arg_name, arg_spec in p4aobj.params:
                args.append({'name' : arg_name,
                             'width' : arg_spec.specifiers['width'],
                             'type' : arg_spec.type_name,
                             'direction' : list(arg_spec.qualifiers)[0]})

            if 'c_extern_t' in ext_pragmas:
                val = ext_pragmas['c_extern_t'].keys()[0]
                is_c_extern = val.lower() == 'true'
                #name_qualifier = "_" + p4aobj.parent.name + "__"
            else:
                if ext_name == 'c_extern_t':
                    is_c_extern = True

            if not is_c_extern:
                raise P42AIRError("extern %s with type %s is not "
                                  "a c extern\n" %
                                  (a, ext_name))
            aname = name_qualifier + p4aobj.name

            cobj = {'name' : aname,
                    'method' : a,
                    'instance' : p4aobj.parent.name,
                    'type' : ext_name}

            if aname in external_actions:
                raise P42AIRError("extern %s with type %s "
                                  "clashes with existing extern name\n" %
                                  (a, ext_name, a))

            external_actions[aname] = cobj

            continue

        acts['doc'] = p4aobj.doc
        acts['src_filename'] = os.path.normpath(p4aobj.filename)
        acts['src_lineno'] = p4aobj.lineno

        act_name = a

        # reset the expression number
        expression_no = 0

        # custom primitives
        try:
            if p4aobj.custom:
                cobj = {}
                cobj['name'] = a

                # TODO: handle arguments

                external_actions[a] = cobj
                try:
                    entity_namer.register_name(a,
                                               p4aobj.filename,
                                               p4aobj.lineno);
                except:
                    cobj['unique_name'] = entity_namer.get_unique_name(a)
                    entity_namer.register_name(cobj['unique_name'],
                                               p4aobj.filename,
                                               p4aobj.lineno);
        except: # in case the p4-hlir doesn't have the custom class variable
            pass


        if len(p4aobj.call_sequence) == 0:
            if p4aobj.filename == '':
                # XXX: IR spec is bad on this point
                # it is possible to declare actions without
                # calls that do nothing that are NOT primitive
                # actions

                # guess that these actions will have non-empty
                # filenames
                
                # no call sequence indicates a primitive action
                primitives[a] = {}
                continue;

        # build up the table argument list
        args = []
        for i in range(len(p4aobj.signature)):
            args.append({ "name" : p4aobj.signature[i],
                          "width" : p4aobj.signature_widths[i] })
            
        acts['args'] = args

        # build up the operations
        ops = []

        tables = []
        #
        # check which tables reference this action
        #
        for tbl, tblobj in p4data.p4_tables.items():
            for tbla in tblobj.actions:
                if a != tbla.name:
                    continue
                if tbl in tables:
                    continue
                tables.append(tbl)

        #
        # check for implicit actions
        # this happens if there are direct counters or meters
        # in this case we end up having to clone the action sets
        # giving them new names
        #

        implicits = collections.OrderedDict()

        for mname, m in stateful_data['meters'].items():
            if m['class'] != 'direct':
                continue

            tbl = m['table']
            if tbl not in tables:
                continue

            if tbl not in implicits:
                implicits[tbl] = collections.OrderedDict()

            if mname in implicits[tbl]:
                continue

            implicits[tbl][mname] = ('meter', m)

        for cname, c in stateful_data['registers'].items():
            if c['class'] != 'direct':
                continue
            if 'counts' not in c or len(c['counts']) == 0:
                continue

            tbl = c['table']
            if tbl not in tables:
                continue

            if tbl not in implicits:
                implicits[tbl] = collections.OrderedDict()

            if cname in implicits[tbl]:
                continue

            implicits[tbl][cname] = ('count', c)

        table_loops = []
        if len(implicits) == 0:
            table_loops.append("")
        else:
            for itbl in implicits:
                # operations with implicit for table itbl
                table_loops.append(itbl)
            for tbl in tables:
                if tbl in table_loops:
                    continue
                if "" in table_loops:
                    continue
                # vanilla operations
                table_loops.append("")

        ops = []
        for op in p4aobj.flat_call_sequence:
            opname = op[0].name

            if opname in p4data.p4_actions:
                # HACK/BUG/HLIR FIXME
                # HLIR incorrectly interprets empty user actions as primitives
                # these then dont get expanded in the caller's flat_call_sequence
                # when they should so we detect them and skip them
                # note we take care not to skip over custom primitives
                prim_actobj = p4data.p4_actions[opname]
                if prim_actobj.flat_call_sequence == 0 and \
                        prim_actobj.filename != '' and \
                        not prim_actobj.custom:
                    continue
            opdata = {}

            opdata['operation'] = op[0].name
            opdata['args'] = []

            #
            # actions which require special treatment
            #

            #
            # count
            #
            if op[0].name == "count" and len(op[1]) <= 2:
                arg_error = 0

                arg = op[1][0]
                if len(op[1]) == 1:
                    arg_opt = 0
                else:
                    arg_opt = op[1][1]
                    supported_types = [int, long,
                                       p4hv.p4_hlir.hlir.p4_headers.p4_field,
                                       p4hv.p4_hlir.hlir.p4_imperatives.p4_signature_ref]

                    if type(arg_opt) not in supported_types:
                        raise P42AIRError("unsupported counter index "
                                          "type %s for action %s (%s)\n" %
                                          (type(arg_opt), a, str(arg_opt)))

                    # Convert the action argument index to a field name
                    if type(arg_opt) == p4hv.p4_hlir.hlir.p4_imperatives.p4_signature_ref:
                        idx = arg_opt.idx
                        arg_opt = p4aobj.signature[idx]

                if type(arg) != p4hv.p4_hlir.hlir.p4_stateful.p4_counter:
                    raise P42AIRError("unsupported counter argument "
                                      "type %s for action %s (%s)\n" %
                                      (type(arg), a, str(arg)))

                types = []
                if "packets" in  arg.type.value:
                    types.append("packets")
                if "bytes" in  arg.type.value:
                    types.append("bytes")

                for t in types:
                    if t == 'packets':
                        prim = 'count'
                    else:
                        prim = 'count_%s' % (t)
                        
                    ops.append({ 'operation' : prim,
                                 'args' : ['%s.value_%s' % (arg.name, t),
                                           arg_opt]})

                continue # move to next op

            #
            # digest
            #
            if op[0].name == "generate_digest" and len(op[1]) == 2:
                dgid = op[1][0]
                dgfl = op[1][1]

                digestname = "_digest_" + dgfl.name + "_" + "%d" % (dgid)
                ops.append({ 'operation' : "generate_digest",
                             'args' : [digestname] })
                if digestname not in digests:
                    digests[digestname] = {'field_list' : dgfl.name,
                                           'identifier' : dgid }
                continue

            # translate arguments
            for arg in op[1]:
                state = {'action_signature' : p4aobj.signature}
                if type(arg) == p4hv.p4_hlir.hlir.p4_expressions.p4_expression:
                    expression_name = "_expression_%s_%d" % (a, expression_no)

                    a_expr = { "expression" : expand_expression(arg, 64, state),
                               "doc" : "expression for action %s" % (a) }
                    # check that the p4 expression has more than just
                    # a right entry
                    if 'left' in state or 'op' in state:
                        action_expressions[expression_name] = a_expr
                        opdata['args'].append("%s" % (expression_name))
                        expression_no += 1
                        continue
                    # just a right entry means we process it as a regular arg
                    arg = state['right']
                if type(arg) == p4hv.p4_hlir.hlir.p4_headers.p4_field:
                    # a field
                    opdata['args'].append("%s.%s" % (arg.instance.name, arg.name))
                    continue

                if type(arg) == p4hv.p4_hlir.hlir.p4_stateful.p4_register:
                    # a register
                    fld = None
                    if arg.width == None:
                        print "Warning: action %s includes " \
                              "vague register reference %s" % (a, str(arg))
                        fld = arg.layout.layout.keys()[0]
                    else:
                        fld = "value"

                    opdata['args'].append("%s.%s" % (arg.name, fld))
                    continue
                if type(arg) == p4hv.p4_hlir.hlir.p4_headers.p4_header_instance:
                    # a header
                    opdata['args'].append("%s" % (arg.name))
                    continue
                if type(arg) == p4hv.p4_hlir.hlir.p4_imperatives.p4_signature_ref:
                    # a reference to an argument
                    idx = arg.idx

                    opdata['args'].append(p4aobj.signature[idx])
                    continue
                if type(arg) == p4hv.p4_hlir.hlir.p4_headers.p4_field_list:
                    # field list
                    opdata['args'].append(arg.name)
                    continue
                if type(arg) == p4hv.p4_hlir.hlir.p4_headers.p4_field_list_calculation:
                    # the result of calculation
                    opdata['args'].append("%s" % (arg.name))
                    continue
                if type(arg) in [int, long]:
                    # a number
                    if arg < 0:
                        opdata['args'].append("%d" % (arg))
                    else:
                        opdata['args'].append("0x%x" % (arg))
                    continue
                if hasattr(p4hv.p4_hlir.hlir, 'p4_sized_integer') and \
                        type(arg) == p4hv.p4_hlir.hlir.p4_sized_integer:
                    # a number with a width
                    opdata['args'].append("%s" % (str(arg)))
                    continue
                if type(arg) == p4hv.p4_hlir.hlir.p4_stateful.p4_meter:
                    opdata['args'].append("%s" % (arg.name))
                    continue

                if type(arg) == p4hv.p4_hlir.hlir.p4_imperatives.p4_register_ref:
                    opdata['args'].append("%s[%d].value" % (arg.register_name, arg.idx))
                    continue

                raise P42AIRError("unsupported action argument "
                                  "type %s for action %s (%s)\n" %
                                  (type(arg), a, str(arg)))

            ops.append(opdata)

        if len(table_loops) > 1:
            print "Note: duplicating action %s due to " \
                  "'direct' stateful entities " % a

        acts['ops'] = ops

        if "" in table_loops:
            # no implicit actions
            # just use the ops as is
            air_action_sets[a] = acts

        # process the implicit actions
        # it is possible that each call of a given action set may
        # include different implicit actions
        for tbl in table_loops:
            if tbl == "": # already done
                continue

            if len(table_loops) == 1:
                aname = a # only one action set so no need to rename
            else:
                aname = "__" + tbl +  "__" + a
                if tbl not in modified_actions:
                    modified_actions[tbl] = collections.OrderedDict()

                # save the modified actions
                # we will use this to affect the table actions later
                modified_actions[tbl][a] = aname

            newacts = copy.deepcopy(acts)
            newacts['name'] = aname

            newacts['doc'] = "action set %s with implicit direct actions" % a

            impl_ops = []

            for impl, implobj in implicits[tbl].items():
                if implobj[0] == 'meter':
                    m = implobj[1]

                    op = {'operation' : 'execute_meter', 'args' : []}
                    op['args'].append(m['name'])
                    op['args'].append('0') # meters can only have instance count 1
                    op['args'].append(str(m['result']))
                    impl_ops.append(op)
                elif implobj[0] == 'count':
                    c = implobj[1]

                    types = []
                    if "packets" in c['type']:
                        types.append("packets")
                    if "bytes" in c['type']:
                        types.append("bytes")

                    for t in types:
                        if t == 'packets':
                            fn = 'count'
                        else:
                            fn = 'count_bytes'

                        op = {'operation' : fn, 'args' : []}
                        op['args'].append(c['name'] + "." + "value_" + t)
                        op['args'].append('0') # counters can only have instance count 1
                        impl_ops.append(op)
                else :
                    raise P42AIRError("BUG: unexected implicit action type %s" %
                                      (implobj[0]))


            newacts['ops'] = impl_ops + newacts['ops']
            air_action_sets[aname] = newacts


    return {"digests" : digests,
            "actions" : air_action_sets,
            "external_actions" : external_actions,
            "modified_actions" : modified_actions,
            "action_expressions" : action_expressions, }

#####################################################
# Output code
#####################################################

def actions_output(outfile, gen_data, options=[]):
    digests = gen_data["digests"]

    if len(digests):
        FOUT(outfile, 0, "##########################################\n");
        FOUT(outfile, 0, "# Digests                                #\n");
        FOUT(outfile, 0, "##########################################\n\n");

        for dgname in digests:
            dg = digests[dgname]

            # digests don't need renamer, always unique
            FOUT(outfile, 0, "\"%s\" :\n" % (dgname));
            FOUT(outfile, 1, "type : digest\n");
            FOUT(outfile, 1, "identifier : %d\n" % (dg['identifier']));
            FOUT(outfile, 1, "field_list : \"%s\"\n" % (dg['field_list']));
            FOUT(outfile, 0, "\n");

    external_actions = gen_data["external_actions"]
    if len(external_actions):
        FOUT(outfile, 0, "##########################################\n");
        FOUT(outfile, 0, "# External functions                     #\n");
        FOUT(outfile, 0, "##########################################\n\n");
        for cp, cpobj in external_actions.items():
            if 'unique_name' in cpobj :
                FOUT(outfile, 0, "\"%s\" :\n" % (cpobj['unique_name']));
                FOUT(outfile, 1, "name : \"%s\"\n" % (cp));
            else:
                FOUT(outfile, 0, "\"%s\" :\n" % (cp));

            FOUT(outfile, 1, "type : external_action\n");
            FOUT(outfile, 0, "\n");

    action_expressions = gen_data["action_expressions"]
    if len(action_expressions) > 0:
        FOUT(outfile, 0, "##########################################\n");
        FOUT(outfile, 0, "# Action Expressions                     #\n");
        FOUT(outfile, 0, "##########################################\n\n");
        for ename, e in action_expressions.items():
            FOUT(outfile, 0, "\"%s\":\n" %(ename));
            FOUT(outfile, 1, "type : expression\n");
            if e['doc'] != None:
                FOUT(outfile, 1, 'doc : "%s"\n' % (e['doc']));
            FOUT(outfile, 1, "expression : \"%s\"\n" % (e['expression']));
            FOUT(outfile, 1, 'format : bracketed_expr\n');
            FOUT(outfile, 0, '\n');

    air_action_sets = gen_data["actions"]

    FOUT(outfile, 0, "##########################################\n");
    FOUT(outfile, 0, "# Action sets                            #\n");
    FOUT(outfile, 0, "##########################################\n\n");

    for aset in air_action_sets:
        asobj = air_action_sets[aset]

        # dont include custom primitives in the action set
        if aset in gen_data["external_actions"]:
            continue

        if 'unique_name' in asobj :
            FOUT(outfile, 0, "\"%s\" :\n" % (asobj['unique_name']));
            FOUT(outfile, 1, 'name : "%s"\n' % (aset));
        else:
            FOUT(outfile, 0, "\"%s\" :\n" % (aset));

        FOUT(outfile, 1, "type : action\n");
        if asobj['doc'] :
            FOUT(outfile, 1, 'doc : "%s"\n' % (asobj['doc']));
        if "src_info" in options:
            if asobj['src_filename'] :
                FOUT(outfile, 1, "src_filename : '%s'\n" % (asobj['src_filename']));
            if asobj['src_lineno'] :
                FOUT(outfile, 1, 'src_lineno : %d\n' % (asobj['src_lineno']));

        if len(asobj['args']) > 0 :
            FOUT(outfile, 1, 'parameter_list :\n')
        for a in asobj['args']:
            if type(a['width']) in [int, long]:
                FOUT(outfile, 2, '- "%s" : %d\n' % (a['name'], a['width']))
            else:
                FOUT(outfile, 2, '- "%s" : "%s"\n' % (a['name'], a['width']))

        if len(asobj['ops']) > 0:
            FOUT(outfile, 1, 'implementation : >-\n')
            for a in asobj['ops']:
                FOUT(outfile, 2, '%s(' % (a['operation']))
                first = 1
                for arg in a['args']:
                    if first == 0:
                        FOUT(outfile, 0, ', ')

                    FOUT(outfile, 0, '%s' % (arg))
                    first = 0
                FOUT(outfile, 0, ');\n')
        if len(asobj['pragmas']) > 0:
            FOUT(outfile, 1, 'pragmas : \n');
            for p in asobj['pragmas']:
                FOUT(outfile, 2, '- "%s"\n' % (p))
        FOUT(outfile, 0, "\n");
