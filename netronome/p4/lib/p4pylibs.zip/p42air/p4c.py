import os, sys, subprocess, time, traceback

from p42air_base import P42AIRBaseError

MSYS2_SHELL = 'usr/bin/sh.exe'
MSYS2_PATH = '/usr/local/bin:/usr/bin:/bin'
USE_CYGWIN_FILE_PATHS = False

class P4CError(P42AIRBaseError):
    pass

def to_cygwin_path(pth):
    if USE_CYGWIN_FILE_PATHS:
        d, p = os.path.splitdrive(os.path.abspath(pth))
        res = ('/%s%s'%(d[:-1], p)).replace('\\', '/')
        return res
    else:
        return pth.replace('\\', '/')
        
def p4c(p4src, p4version, output, includes=(), defines=(), 
        target='bmv2-ss-p4org', arch='ss', verbosity=0,
        gen_bmv2=True, gen_p4info=True, gen_ir=False, gen_pprint_p4_16=False):
    assert os.path.exists(p4src), 'invalid p4src file'
    output = os.path.splitext(output)[0]
    if sys.platform == 'win32':
        includes = ' '.join(['-I %s'%to_cygwin_path(incl) for incl in includes])
    else:
        includes = ' '.join(['-I %s'%incl for incl in includes])

    defines = ' '.join(['-D %s'%dfn for dfn in defines])
    p4c_cmd_fmt = '--p4v {p4version} {includes} {defines} --target {target} --arch {arch} '
    if gen_bmv2:
        p4c_cmd_fmt += '-o {output}.bmv2.json '
    if gen_ir:
        p4c_cmd_fmt += '--toJSON {output}.ir.json '
    if gen_p4info:
        p4c_cmd_fmt += '--p4runtime-format json --p4runtime-file {output}.p4info.json '
    if gen_pprint_p4_16:
        p4c_cmd_fmt += '--pp {output}.pp16.p4 '
    p4c_cmd_fmt += '{p4src} '+(''.join(['-v']*min(verbosity, 3)))
    
    # env var is set, overrides other options
    if 'P4C_BIN_DIR' in os.environ:
        p4_bin_dir = os.path.normpath(os.path.abspath(os.environ['P4C_BIN_DIR']))
    # running as a nfp4c binary, the p4c compiler is in the same directory
    elif hasattr(sys, 'frozen'):
        p4_bin_dir = os.path.dirname(sys.executable)
    # running from source
    else:
        sdk_dir = os.path.dirname(os.path.dirname(__file__))
        # handle case running from within a zip library
        if sdk_dir.endswith('.zip') and os.path.isfile(sdk_dir):
            sdk_dir = os.path.dirname(os.path.dirname(os.path.dirname(sdk_dir)))
            
        p4_bin_dir = os.path.normpath(os.path.join(sdk_dir, 'p4', 'bin'))
        
    P4C_PATH = os.path.join(p4_bin_dir, 'p4c-bm2-ss')
    if sys.platform == 'win32':
        P4C_PATH += '.exe'
    
    assert os.path.exists(P4C_PATH), P4C_PATH
        
    if sys.platform == 'win32':
        MSYS2_ROOT = os.path.join(p4_bin_dir, 'msys64')
        # change paths to cygwin format and setup env PATH
        output = to_cygwin_path(output)
        p4src = to_cygwin_path(p4src)
        args = [os.path.normpath(os.path.join(MSYS2_ROOT, MSYS2_SHELL)), '-c',
            ('export PATH=%s && %s '%(MSYS2_PATH, to_cygwin_path(P4C_PATH))+
             p4c_cmd_fmt.format(**locals()))]
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startupinfo.wShowWindow = subprocess.SW_HIDE                
        use_shell = False
    else:
        args = [P4C_PATH + " " + p4c_cmd_fmt.format(**locals())]
        startupinfo = None
        use_shell = True

    p = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, startupinfo=startupinfo, shell=use_shell)
    so, se = p.communicate()
    return p.returncode, so, se
