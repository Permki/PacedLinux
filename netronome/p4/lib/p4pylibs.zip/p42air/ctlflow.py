import os, sys, collections

import p4_hlir_versions as p4hv

import graphs

from p42air_common import I, FOUT, expand_expression, P42AIRError

# build up the control flow based on a start node
def build_flow(p4data, start):
    transitions = []
    conditionals = collections.OrderedDict()
    tables = []

    if start == None:
        return {"pydot_string" : "",
                "transitions" : transitions,
                "tables" : tables,
                "conditionals" : conditionals,
                "start" : ""}

    if start != None:
        stackdata = [start]
    stackdone = []

    while len(stackdata) != 0:
        op = stackdata.pop(0)
        stackdone.append(op.name)

        if type(op) == p4hv.p4_hlir.hlir.p4_tables.p4_table:
            # dont process the same table twice
            if op in tables:
                continue
            tables.append(op)

            # check if all the transitions are to the same place
            # treat this as a special case
            always = 0
            if len(set(op.next_.values())) == 1:
                if op.next_.values()[0] == op.base_default_next:
                    always = 1

            if op.action_profile != None:
                print >> sys.stderr, ("warning: action profile in table %s not supported, " \
                                      "this will be ignored" % str(op.name))

            action_case = False
            for nxt in op.next_:
                transition = {}
                transition['src'] = op.name

                nxtobj = op.next_[nxt]
                if nxtobj == None:
                    # the end
                    transition['dest'] = "exit_control_flow"
                else:
                    transition['dest'] = nxtobj.name

                    # only add the node if it hasn't been added already
                    if transition['dest'] not in stackdone:
                        stackdata.insert(0, nxtobj)

                if always:
                    transition['cond'] = 'action = always'
                elif type(nxt) == str:
                    transition['cond'] = 'action = %s' %(nxt)
                elif type(nxt) == p4hv.p4_hlir.hlir.p4_imperatives.p4_action:
                    transition['cond'] = 'action = %s' %(nxt.name)
                    transition['action'] = nxt.name
                    action_case = True
                else:
                    raise P42AIRError("Unsupported transition type " +
                                      "%s for table %s\n" % (type(op), op.name))

                transitions.append(transition)
                if always:
                    break

            if action_case:
                transition = {}
                transition['src'] = op.name
                if op.base_default_next == None:
                    transition['dest'] = "exit_control_flow"
                else:
                    transition['dest'] = op.base_default_next.name
                transition['cond'] = 'action = default'
                transitions.append(transition)

        elif type(op) == p4hv.p4_hlir.hlir.p4_tables.p4_conditional_node:
            # dont process the same conditional twice
            if op.name in conditionals:
                continue

            conditionals[op.name] = op

            # force false then true
            # this forces the true condition to be process on the stack first
            order = [False, True]
            for k in order:
                nxtobj = op.next_[k]

                transition = {}
                transition['src'] = op.name
                if nxtobj == None:
                    transition['dest'] = "exit_control_flow"
                else:
                    transition['dest'] = nxtobj.name

                    # only add the node if it hasn't been added already
                    if transition['dest'] not in stackdone:
                        stackdata.insert(0, nxtobj)
            
                if k == True:
                    transition['cond'] = 'condition = true'
                else:
                    transition['cond'] = 'condition = false'

                transitions.append(transition)
        else:
            raise P42AIRError("Unsupported type in control flow %s\n" % (type(op)))

    return {"transitions" : transitions,
            "tables" : tables,
            "conditionals" : conditionals,
            "start" : start.name}

def ctlflow_gen(p4data, entity_namer, options=[]):
    # process control flow
    # egress and ingress

    # find the ingress entry point that has no dependencies
    # this is the ingress entry node
    ingress_flow = {'conditionals' : [], 'tables' : [], 'transitions' : []}
    for k in p4data.p4_ingress_ptr.keys():
        if not k or len(k.dependencies_to) != 0:
            continue
        ingress_flow = build_flow(p4data, k)
        break

    egress_flow = build_flow(p4data, p4data.p4_egress_ptr)

    ingress_condionals = collections.OrderedDict()
    for cname in ingress_flow['conditionals']:
        ent = {}
        c = ingress_flow['conditionals'][cname]
        try:
            entity_namer.register_name(c.name,
                                       c.filename,
                                       c.lineno);
        except:
            ent['unique_name'] = entity_namer.get_unique_name(c.name)
            entity_namer.register_name(ent['unique_name'],
                                       c.filename,
                                       c.lineno);

        ent['name'] = c.name
        ent['doc'] = c.doc
        if "src_info" in options:
            ent['src_filename'] = os.path.normpath(c.filename)
            ent['src_lineno'] = c.lineno
        ent['condition'] = expand_expression(c.condition, 8)
        ingress_condionals[cname] = ent
    ingress_flow['conditionals'] = ingress_condionals

    egress_condionals = collections.OrderedDict()
    for cname in egress_flow['conditionals']:
        c = egress_flow['conditionals'][cname]
        ent = {}
        try:
            entity_namer.register_name(c.name,
                                       c.filename,
                                       c.lineno);
        except:
            ent['unique_name'] = entity_namer.get_unique_name(c.name)
            entity_namer.register_name(ent['unique_name'],
                                       c.filename,
                                       c.lineno);
        ent['name'] = c.name
        ent['doc'] = c.doc
        if "src_info" in options:
            ent['src_filename'] = os.path.normpath(c.filename)
            ent['src_lineno'] = c.lineno
        ent['condition'] = expand_expression(c.condition, 8)

        egress_condionals[cname] = ent

    egress_flow['conditionals'] = egress_condionals

    # process tables together
    all_tbls = ingress_flow['tables'] + egress_flow['tables']
    # make sure they are unique
    all_tbls = list(set(all_tbls))

    air_tables = []
    for t in all_tbls:
        ent = {}
        try:
            entity_namer.register_name(t.name,
                                       t.filename,
                                       t.lineno);
        except:
            ent['unique_name'] = entity_namer.get_unique_name(t.name)
            entity_namer.register_name(ent['unique_name'],
                                       t.filename,
                                       t.lineno);
        ent['name'] = t.name
        ent['doc'] = t.doc
        ent['pragmas'] = []
        if "src_info" in options:
            ent['src_filename'] = os.path.normpath(t.filename)
            ent['src_lineno'] = t.lineno

        # get max_entries
        # use the min_size value for the max if defined
        # then override if max_size is defined
        max_entries = None
        if t.min_size:
            max_entries = t.min_size
        if t.max_size:
            max_entries = t.max_size
            
        # add an extra entry for the default rule
        if max_entries:
            max_entries += 1

        ent['support_timeout'] = t.support_timeout
        if ent['support_timeout']:
            ent['pragmas'].append('support_timeout')

        ent['max_entries'] = max_entries
        matches = []
        for m in t.match_fields:
            fld, mtype, mask = m
            match = {}
            if type(fld) == p4hv.p4_hlir.hlir.p4_headers.p4_field:
                match['field'] = "%s.%s" % (fld.instance.name, fld.name)
            elif type(fld) == p4hv.p4_hlir.hlir.p4_headers.p4_header_instance:
                match['field'] = "%s" % (fld.name)
            else:
                sys.stderr.write("Unsupported match field type %s for table %s" %
                                  (type(fld), t.name))
                sys.exit(1)

            mt = mtype.value
            mtmap = { "P4_MATCH_EXACT"   : "exact",
                      "P4_MATCH_TERNARY" : "ternary",
                      "P4_MATCH_RANGE"   : "range",
                      "P4_MATCH_LPM"     : "lpm",
                      "P4_MATCH_INDEX"   : "index",
                      "P4_MATCH_VALID"   : "valid", }

            if mt not in mtmap:
                sys.stderr.write("Unsupported match type %s for table %s" %
                                  (mt, t.name))
                sys.exit(1)

            match['type'] = mtmap[mt]
            match['mask'] = mask
            matches.append(match)
        ent['matches'] = matches
        
        actions = []
        for a in t.actions:
            actions.append(a.name)
        ent['actions'] = actions

        air_tables.append(ent)

    if "ingress_graph" in options:
        graphs.ctlflow_graph(ingress_flow, options["ingress_graph"])

    if "egress_graph" in options:
        graphs.ctlflow_graph(egress_flow, options["egress_graph"])

    return (ingress_flow, egress_flow, air_tables)

def ctlflow_gen_stage2(gen_data, actions_data):
    (ingress_flow, egress_flow, air_tables) = gen_data

    modified_actions = actions_data['modified_actions']

    for flow in [ingress_flow, egress_flow]:
        if len(flow['transitions']) == 0:
            continue

        # IR dot format
        ir_pydot_string = ""
        ir_pydot_string += 'digraph {\n'

        for t in flow['transitions']:
            cond = t['cond']

            if 'action' in t and t['src'] in modified_actions:
                tbl = t['src']

                mod_acts = modified_actions[tbl]
                if t['action'] in mod_acts:
                    cond = cond.replace(t['action'], mod_acts[t['action']])

            ir_pydot_string += I(3) + '%s -> %s [%s]\n' % (t['src'], t['dest'], cond)

        ir_pydot_string += I(2) + '}\n'
        flow['ir_pydot_string'] = ir_pydot_string

#####################################################
# Output code
#####################################################

def ctlflow_output(outfile, gen_data, actions_data):
    (ingress_flow, egress_flow, air_tables) = gen_data

    FOUT(outfile, 0, "##########################################\n");
    FOUT(outfile, 0, "# Ingress and Egress tables              #\n");
    FOUT(outfile, 0, "##########################################\n\n");

    for t in air_tables:
        if 'unique_name' in t :
            FOUT(outfile, 0, "\"%s\":\n" %(t['unique_name']));
            FOUT(outfile, 1, 'name : "%s"\n' % (t['name']));
        else:
            FOUT(outfile, 0, "\"%s\":\n" %(t['name']));
        FOUT(outfile, 1, "type : table\n");
        if t['doc'] != None:
            FOUT(outfile, 1, 'doc : "%s"\n' % (t['doc']));

        if len(t['matches']) > 0:
            FOUT(outfile, 1, 'match_on : \n');
        for m in t['matches']:
            if m['mask'] == None:
                FOUT(outfile, 2, "\"%s\" : \"%s\"\n" % (m['field'], m['type']));
            else:
                FOUT(outfile, 2, "\"%s\" : \"%s, mask 0x%x\"\n" % (m['field'], m['type'], m['mask']));

        if len(t['actions']) > 0:
            FOUT(outfile, 1, 'allowed_actions : \n');
        for a in t['actions']:
            modact = a

            # see if the action for this table has been modified
            modified_actions = actions_data['modified_actions']
            tblname = t['name']
            if t['name'] in modified_actions:
                if a in modified_actions[t['name']]:
                    modact = modified_actions[t['name']][a]

            FOUT(outfile, 2, '- "%s"\n' % (modact));

        if t['max_entries']:
            FOUT(outfile, 1, 'max_entries : %d\n' %(t['max_entries']))
        if 'src_filename' in t:
            FOUT(outfile, 1, "src_filename : '%s'\n" %(t['src_filename']))

        if 'src_lineno' in t:
            FOUT(outfile, 1, 'src_lineno : %d\n' %(t['src_lineno']))

        if len(t['pragmas']) > 0:
            FOUT(outfile, 1, 'pragmas :\n')
            for pragma in t['pragmas']:
                FOUT(outfile, 2, '- "%s"\n' %(pragma))

        FOUT(outfile, 0, '\n');

    if len(ingress_flow['transitions']) != 0:
        FOUT(outfile, 0, "##########################################\n");
        FOUT(outfile, 0, "# Ingress conditionals sets              #\n");
        FOUT(outfile, 0, "##########################################\n\n");
        for cname, c in ingress_flow['conditionals'].items():
            if 'unique_name' in c:
                FOUT(outfile, 0, "\"%s\":\n" %(c['unique_name']));
                FOUT(outfile, 1, 'name : "%s"\n' % (c['name']));
            else:
                FOUT(outfile, 0, "\"%s\":\n" %(c['name']));
            FOUT(outfile, 1, "type : conditional\n");
            FOUT(outfile, 1, 'format : bracketed_expr\n');
            if c['doc'] != None:
                FOUT(outfile, 1, 'doc : "%s"\n' % (c['doc']));
            FOUT(outfile, 1, "condition : \"%s\"\n" % (c['condition']));
            if 'src_filename' in c:
                FOUT(outfile, 1, "src_filename : '%s'\n" %(c['src_filename']))

            if 'src_lineno' in c:
                FOUT(outfile, 1, 'src_lineno : %d\n' %(c['src_lineno']))

            FOUT(outfile, 0, '\n');

        FOUT(outfile, 0, "##########################################\n");
        FOUT(outfile, 0, "# Ingress control flow                   #\n");
        FOUT(outfile, 0, "##########################################\n\n");

        FOUT(outfile, 0, "ingress_flow:\n");
        FOUT(outfile, 1, "type : control_flow\n");
        FOUT(outfile, 1, 'doc : "control flow for ingress"\n');
        FOUT(outfile, 1, 'format : dot\n');
        FOUT(outfile, 1, 'start_state : "%s"\n' % (ingress_flow['start']));
        FOUT(outfile, 1, 'implementation : >-\n');

        FOUT(outfile, 2, '%s' % ingress_flow['ir_pydot_string'])
        FOUT(outfile, 0, '\n');

    if len(egress_flow['transitions']) != 0:
        FOUT(outfile, 0, "##########################################\n");
        FOUT(outfile, 0, "# Egress conditionals sets               #\n");
        FOUT(outfile, 0, "##########################################\n\n");
        for cname, c in egress_flow['conditionals'].items():
            if 'unique_name' in c:
                FOUT(outfile, 0, "\"%s\":\n" %(c['unique_name']));
                FOUT(outfile, 1, 'name : "%s"\n' % (c['name']));
            else:
                FOUT(outfile, 0, "\"%s\":\n" %(c['name']));

            FOUT(outfile, 1, "type : conditional\n");
            FOUT(outfile, 1, 'format : bracketed_expr\n');
            if c['doc'] != None:
                FOUT(outfile, 1, 'doc : "%s"\n' % (c['doc']));
            FOUT(outfile, 1, "condition : \"%s\"\n" % (c['condition']));
            FOUT(outfile, 0, '\n');

        FOUT(outfile, 0, "##########################################\n");
        FOUT(outfile, 0, "# Egress control flow                    #\n");
        FOUT(outfile, 0, "##########################################\n\n");

        FOUT(outfile, 0, "egress_flow:\n");
        FOUT(outfile, 1, "type : control_flow\n");
        FOUT(outfile, 1, 'doc : "control flow for egress"\n');
        FOUT(outfile, 1, 'format : dot\n');
        FOUT(outfile, 1, 'start_state : \"%s\"\n' % (egress_flow['start']));
        FOUT(outfile, 1, 'implementation : >-\n');
        FOUT(outfile, 2, '%s' % egress_flow['ir_pydot_string'])
        FOUT(outfile, 0, '\n');

    FOUT(outfile, 0, "##########################################\n");
    FOUT(outfile, 0, "# Processor layout                       #\n");
    FOUT(outfile, 0, "##########################################\n\n");

    FOUT(outfile, 0, "layout:\n")
    FOUT(outfile, 1, "type : processor_layout\n");
    FOUT(outfile, 1, "format : list\n");
    FOUT(outfile, 1, "implementation :\n");
    FOUT(outfile, 2, "- parser\n");
    if len(ingress_flow['transitions']) != 0:
        FOUT(outfile, 2, "- ingress\n");
    if len(egress_flow['transitions']) != 0:
        FOUT(outfile, 2, "- egress\n");
    FOUT(outfile, 0, '\n');
