VERSION = '1.0.1'
DESCRIPTION = 'P4 to IR Compiler.'

try:
    import __repo_version__
    VERSION += '-'+__repo_version__.HASH
except ImportError, err:
    VERSION += '-devel'
