"""
AIR exception definitions
"""

class AirValidationError(Exception):
    """
    Error validating some AIR representation
    """
    pass

class AirFatalError(Exception):
    """
    Fatal AIR Error
    """
    pass

class AriRefError(Exception):
    """
    Error referencing some AIR object
    """
    pass
