#!/usr/bin/python

import os, sys, json, copy, re, pprint, argparse, multiprocessing, subprocess, traceback
import textwrap, warnings
from StringIO import StringIO

VERSION = '1.4.0'
DESCRIPTION = 'Makefile generator and builder for P4/ManagedC Applications.'
NOTES = '''Use following defines (-D/--define) to enable/disable certain features:
  MC_INIT:
    For managed c applications, call mc_init() and mc_init_master()
    for per ME and global initialisation.

  PIF_PLUGIN_INIT:
    For P4 applications, call pif_plugin_init() and pif_plugin_init_master()
    for per ME and global initialisation.

  PIF_GLOBAL_TRAFFIC_CLASS_DISABLED:
    For P4 applications, disable translation between traffic class and queue
    numbers.
'''

try:
    from nfp_pif_gen import __repo_version__
    VERSION += '-'+__repo_version__.HASH
except ImportError, err:
    VERSION += '-devel'

SDK_ENV = {
    'SDKDIR': '',
    'SDKTOOLSDIR': '',
    'SDKP4DIR': '',
}

DEFAULT_PLATFORM = 'starfighter1'
DEFAULT_APP_TYPE = 'pif_app_nfd'
DEFAULT_P4_VERSION = '1.0'
DEFAULT_P4_COMPILER = 'hlir'

MINGW_PATHS = True

COMPONENT_ENV_PATHS = {
    'libnfd': 'NGNFDDIR',
    'nfdpci': 'NGNFDDIR',
    'dcfl': 'DCFLDIR',
    'flowenv': 'FLOWENVDIR',
    'flowenv_init': 'FLOWENVDIR',
    'flowcache': 'FLOWCACHEDIR',
    'flowcache_timeout': 'FLOWCACHEDIR',
    'gro': 'GRODIR',
    'blm': 'FLOWENVDIR',
    'nfd_svc': 'NGNFDDIR',
    'nfd_pcie_sb': 'NGNFDDIR',
    'nfd_pcie_pd': 'NGNFDDIR',
    'nfd_pcie_pci_out_me': 'NGNFDDIR',
    'nfd_pcie_pci_in_gather': 'NGNFDDIR',
    'nfd_pcie_pci_in_issue': 'NGNFDDIR',
    'nfd_pcie_notify': 'NGNFDDIR',
    'pktio_lib': 'FLOWENVDIR',
    'blm0': 'FLOWENVDIR',
    'blm1': 'FLOWENVDIR',
    'gro0': 'GRODIR',
    'appsbase': 'APPSBASE',
    #'crypto': 'TLSSHELLDIR',
    #'crypto0': 'TLSSHELLDIR',

    #'nfp_pif': 'PIFROOTDIR',
    #'microc': 'MICROCLIB',
    #'microcode': 'MICROCODELIB', # ???
}

TOOLS = ('compiler', 'assembler')

TOOL_ARGS_MAP = {
    'compiler': {
        'forceinclude': '-FI%s',
        'include': '-I%s',
        'src': '%s',
        'define': '-D%s',
        'flag': '-%s',

        'debug_info': 'Zi',
        'nfcc_ng': 'ng',
        'verbose': 'verbose',
    },
    'assembler': {
        'forceinclude': '-include %s',
        'include': '-I%s',
        'src': '%s',
        'define': '-D%s',
        'flag': '-%s',

        'debug_info': 'go',
        'verbose': 'verbose',
    },
    'linker': {
        'flags': '-%s',
        'pico': '-i %s -e %s',

        'debug_info': 'g',
        'verbose': '-verbose',
    },
}

OPTIONAL_COMPONENT_DEFAULTS = {
    'flowcache': True,
    'gro': True,
    'libnfd': True,
    #'crypto' : False,
    'pcie_x2': False,
    'pcie_x4': False,
}

OPTIONAL_COMPONENT_DISABLED_DEFINES = {
    'flowcache': 'PIF_GLOBAL_FLOWCACHE_DISABLED',
    'gro':       'PIF_GLOBAL_GRO_DISABLED',
    'libnfd':    'PIF_GLOBAL_NFD_DISABLED',
}

def _warn(msg):
    if 1:
        print >> sys.stderr, 'warning: %s'%msg
    else:
        warnings.warn(msg)

def relpath(p, m):
    p = os.path.abspath(p)
    m = os.path.abspath(m)
    if os.path.splitdrive(p)[0].lower() == os.path.splitdrive(m)[0].lower():
        res = os.path.relpath(p, m).replace('\\', '/')
    else:
        res = p.replace('\\', '/')
    return res

# collect env var filepaths
ENV_PATHS = {}
PATH_PREFIXES = []
def normpath(p, prefix_path=True):
    if sys.platform == 'win32' and MINGW_PATHS:
        p = os.path.normpath(p).replace('\\', '/')
    else:
        p = os.path.normpath(p)

    if prefix_path:
        for pth, env in PATH_PREFIXES:
            if p.startswith(pth):
                return '$(%s)/%s'%(env, p[len(pth)+int(not pth.endswith('/')):])

    return p

class PIFJSONBuilder(object):
    def __init__(self, nffw_output_filename, pif_root_dir, pif_out_dir,
                 app_type, project_config, enabled_optional_components):
        self.nffw_output_filename = nffw_output_filename
        self.project_name = os.path.splitext(os.path.basename(nffw_output_filename))[0]
        self.project_dir = os.path.abspath(os.path.normpath(os.path.expanduser(os.path.dirname(nffw_output_filename))))
        self.project_config = project_config
        self.enabled_optional_components = enabled_optional_components
        self.app_type = app_type
        self.pif_root_dir = pif_root_dir
        if pif_out_dir is None:
            self.pif_out_dir = self.project_dir
        else:
            self.pif_out_dir = os.path.abspath(os.path.normpath(os.path.expanduser(pif_out_dir)))
            if self.pif_out_dir == self.project_dir:
                raise Exception, 'if specified, PIFOUTDIR cannot be the same as OUTDIR'

    def load(self, apps_base=None, variant=None):
        self.components = json.load(open(os.path.join(self.pif_root_dir, 'me', 'apps', 'common', 'build', 'components.json')))

        if apps_base is not None:
            pif_apps_base = apps_base
        else:
            pif_apps_base = os.path.join(self.pif_root_dir, 'me', 'apps')

        if variant:
            self.app = json.load(open(os.path.join(pif_apps_base, self.app_type, 'build', 'app.%s.json'%variant)))
        else:
            self.app = json.load(open(os.path.join(pif_apps_base, self.app_type, 'build', 'app.json')))

        self.components.update(self.app['components'])
        self.app_vars = copy.copy(self.app['vars'])
        if apps_base is not None:
            self.app_vars['PIFAPPDIR'] = os.path.join(pif_apps_base, self.app_type)
        self.app_vars['PIFROOTDIR'] = self.pif_root_dir
        self.app_vars['PIFOUTDIR'] = self.pif_out_dir
        self.app_vars['PROJECT'] = self.project_name
        self.app_vars['os.sep'] = '/' if MINGW_PATHS else os.sep

    def requires_expr(self, expr):
        if expr is None:
            return False
        env = {}
        for comp, default in OPTIONAL_COMPONENT_DEFAULTS.items():
            env[comp] = True if comp in self.enabled_optional_components else False
        res = eval(expr, env)
        assert type(res) is bool
        return res

    def process_targets(self, sku, platform, override_platform_json,
            p4_src, sandbox_c, c_includes, c_defines, src_base_dir,
            custom_load_list, custom_load_me, custom_load_linker_args, verbosity,
            prefix_path=True, process_cmd_opts=True, process_stdlib=True, merge_common_settings=True,
            scs_codeshare_format=True):

        platform_custom = '%s:%s'%(platform, sku)
        self.platform = platform_custom if platform_custom in self.app['platforms'] else platform
        if sku is None:
            psku = self.app['platforms'].get(self.platform, {}).get('chip', {}).get('sku', None)
            self.sku = psku if psku is not None else self.app.get('chip', {}).get('sku', None)
        else:
            self.sku = sku

        if self.sku is None:
            raise Exception, 'SKU not set on command line, global json or platform overrides'

        if override_platform_json is not None:
            self.app['platforms'][self.platform] = json.load(open(override_platform_json))[self.platform]

        self.app_vars['RTU_NCTX'] = 4 if self.project_config['reduced_thread_usage'] else 8

        # some sanity checks on custom loads
        lcme, lcll = len(custom_load_me), len(custom_load_list)
        if lcme > 0 and lcll == 0:
            raise Exception, 'at least one custom load list must be specified'
        if lcll > 0 and lcme == 0:
            raise Exception, 'at least one custom load ME must be specified'
        if lcll > 1 and lcme != lcll:
            raise Exception, 'ambiguous custom load options'
        if lcll == 1 and lcme > 1:
            custom_load_list = lcme * custom_load_list

        # collect and format all build info needed by a target.
        # process component targets before application targets to collect extra
        # mes from disabled optional components.
        self.list_mes = {}
        self.scs_defs = []
        self.target_def = {}
        self.codeless_targets = []
        self.worker_mes = []

        extra_mes = []
        targets = sorted(self.app['targets'].keys(), key=lambda v: self.app['targets'][v]['type'] == 'application')
        for target in targets:
            if verbosity['generate']: self.notify('processing target %s'%target)
            tinfo = self.app['targets'][target]
            assert not ('compiler' in tinfo and 'assembler' in tinfo), 'a target cannot have both compiler and assembler sections'

            # skip disabled components
            if not tinfo.get('enabled', True):
                continue

            list_name = tinfo['list']
            pmes = self.app['platforms'].get(self.platform, {}).get('targets', {}).get(target, {}).get('mes', None)

            mes = pmes if pmes is not None else tinfo.get('mes', [])

            # resolve vars
            mes = [me%self.app_vars for me in mes]

            # skip disabled optional components
            if 'requires' in tinfo and not self.requires_expr(tinfo['requires']):
                if tinfo.get('reuse_mes', False):
                    extra_mes.extend(mes)
                if verbosity['generate']: self.notify('\tskipping target, requirement failed: %s'%tinfo['requires'])
                continue

            # remove mes allocated to custom loads
            for me in custom_load_me:
                if me in mes:
                    if tinfo['type'] == 'application':
                        self.warn('custom load me is used by a worker me, removing worker assignment')
                        mes.remove(me)
                    else:
                        raise Exception, 'custom load me conflict, custom load me (%s) used by %s'%(me, target)

            # add extra mes to the worker mes and sort to assure islands are filled before mes
            if tinfo['type'] == 'application' and extra_mes:
                extra_mes = [me%self.app_vars for me in extra_mes]
                mes.extend(extra_mes)
                mes.sort(key=lambda v: self.iid2tuple(v))

            codeless = False
            if ('assembler' in tinfo and 'flags' in tinfo['assembler'] and
                  'codeless' in tinfo['assembler']['flags']):
                codeless = True
                self.codeless_targets.append(list_name)

            if not mes and not codeless:
                continue

            application_me_count = self.project_config['application_me_count']
            if application_me_count > 0 and tinfo['type'] == 'application':
                min_mes = len([meid for meid in mes if meid.split('.')[-1] == 'me0']) if not self.project_config['simulator'] else 1
                if self.project_config['shared_codestore']:
                    min_mes *= 2
                    app_me_count_scs = max(min_mes, application_me_count)
                    if app_me_count_scs != application_me_count or application_me_count > len(mes):
                        hw_warn = ' and building for hardware' if not self.project_config['simulator'] else ''
                        self.warn('shared code store enabled%s, using %s mes instead of %s'%(
                            hw_warn, app_me_count_scs, application_me_count))
                    app_me_count = app_me_count_scs
                else:

                    if application_me_count < min_mes and not self.project_config['simulator']:
                        self.warn('building for hardware, using %s mes instead of %s'%(
                            min_mes, application_me_count))
                    app_me_count = max(min_mes, application_me_count)
            else:
                app_me_count = len(mes)

            assigned = 0
            for meidx in range(len(mes)):
                me = mes[meidx]
                isl, mestr = me.split('.', 1)
                menum = int(mestr[2:])
                list_me = me
                # skip odd mes for shared codestore in app lists
                if self.project_config['shared_codestore'] and tinfo['type'] == 'application':# and menum % 2:
                    if menum % 2:
                        continue
                    # use grouped me scs notation (for PS)
                    elif not scs_codeshare_format:
                        # skip if there is no odd pair defined in the json
                        me_odd = '%s.me%s'%(isl, menum+1)
                        if me_odd not in mes:
                            if verbosity['generate']:
                                self.notify('%s: skipping me %s, not in available workers'%(str(target), me_odd))
                            continue
                        list_me = '%s.tg%s'%(isl, menum//2)
                if list_name not in self.list_mes:
                    self.list_mes[list_name] = []
                self.list_mes[list_name].append(list_me)
                if tinfo['type'] == 'application':
                    self.worker_mes.append(me)
                assigned += 1
                # use codeshare scs parameters (for makefiles)
                if self.project_config['shared_codestore'] and tinfo['type'] == 'application' and scs_codeshare_format:
                    me_odd = '%s.me%s'%(isl, menum+1)
                    if me_odd in mes:
                        self.list_mes[list_name].append(me_odd)
                        self.worker_mes.append(me_odd)
                        self.scs_defs.append('%s %s'%(me, me_odd))
                        assigned += 1
                    else:
                        self.list_mes[list_name].remove(me)
                        assigned -= 1

                if assigned >= app_me_count:
                    break

            self.target_def[list_name] = {}
            for target_tool in TOOLS:
                self.target_def[list_name].update({target_tool: {
                    'defines': [],
                    'include': [],
                    'forceinclude': [],
                    'dependencies': [],
                    'flags': [],
                    'src': [],
                    'root': '',
                    'add': False,
                    'type': 'user',
                }})

            if verbosity['generate'] and mes:
                self.notify('\tallocated mes: %s'%', '.join(mes))

            disabled_optional_components = [comp for comp in OPTIONAL_COMPONENT_DEFAULTS if comp not in self.enabled_optional_components]

            for target_tool in TOOLS:
                if target_tool in tinfo:
                    components = tinfo.get('components', [])

                    # build up a set of all components
                    # we traverse components and subcomponents to form the final set
                    all_components = set()
                    to_process = set(components)
                    while len(to_process):
                        comp = to_process.pop()
                        if comp in all_components:
                            continue
                        skip = True if 'requires' in tinfo and not self.requires_expr(tinfo['requires']) else False
                        if not self.components[comp].get('enabled', True) or comp in disabled_optional_components or skip:
                            if verbosity['generate']: self.notify('\tskipping component %s, a requirement failed'%comp)
                            continue

                        if not process_stdlib and comp in ('standardlibrary', 'microc'):
                            continue

                        if 'components' in self.components[comp]:
                            to_process |= set(self.components[comp]['components'])

                        all_components.add(comp)

                    for comp in all_components:
                        comp_path = self.read_component_path(comp)
                        ptool = self.app['platforms'].get(self.platform, {}).get('targets', {}).get(target, {}).get(target_tool, {})
                        defines = ptool['defines'] if 'defines' in ptool else tinfo[target_tool].get('defines', [])
                        flags = ptool['flags'] if 'flags' in ptool else tinfo[target_tool].get('flags', [])

                        if target_tool in self.components[comp] and 'defines' in self.components[comp][target_tool]:
                            defines.extend(self.components[comp][target_tool]['defines'])
                        if target_tool in self.components[comp] and 'flags' in self.components[comp][target_tool]:
                            flags.extend(self.components[comp][target_tool]['flags'])
                        common_defines = self.read_common_defines() if merge_common_settings else []

                        common_flags = self.read_common_flags(target_tool)
                        if verbosity['build']:
                            common_flags.append(TOOL_ARGS_MAP[target_tool]['verbose'])

                        if target_tool in self.components[comp]:

                            for ppd in common_defines + self.components[comp][target_tool].get('defines', []) + defines:
                                if ppd not in self.target_def[list_name][target_tool]['defines']:
                                    self.target_def[list_name][target_tool]['defines'].append(ppd)

                            for cf in common_flags + self.components[comp][target_tool].get('flags', []) + flags:
                                if cf not in self.target_def[list_name][target_tool]['flags']:
                                    self.target_def[list_name][target_tool]['flags'].append(cf)
                            for file_path in ('include', 'forceinclude', 'src', 'dependencies'):
                                for p in self.components[comp][target_tool].get(file_path, []):
                                    p = normpath(os.path.join(comp_path, p%self.app_vars), prefix_path)
                                    if p not in self.target_def[list_name][target_tool][file_path]:
                                        self.target_def[list_name][target_tool][file_path].append(p)

                            if target_tool == 'assembler' and 'root' in self.components[comp][target_tool]:
                                p = normpath(os.path.join(comp_path, self.components[comp][target_tool]['root']%self.app_vars), prefix_path)
                                self.target_def[list_name][target_tool]['root'] = p

                    # add sandbox c files to application type list files
                    if sandbox_c is not None and target_tool == 'compiler' and tinfo['type'] == 'application':
                        self.target_def[list_name]['compiler']['src'].extend([relpath(sc, src_base_dir) for sc in sandbox_c])
                        if c_includes:
                            self.target_def[list_name]['compiler']['include'].extend(
                                [relpath(ci, src_base_dir) for ci in c_includes])

                    if target_tool == 'compiler' and tinfo['type'] == 'application':
                        if c_defines:
                            self.target_def[list_name]['compiler']['defines'].extend(c_defines)

                    self.target_def[list_name][target_tool]['add'] = True
                    self.target_def[list_name][target_tool]['type'] = tinfo['type']

                    break

    def read_common_defines(self):
        pcommon_defines = self.app['platforms'].get(self.platform, {}).get('common', {}).get('defines', None)
        common_defines = pcommon_defines if pcommon_defines is not None else self.app['common'].get('defines', [])
        common_defines.append('SIMULATION=%s'%int(self.project_config['simulator']))
        common_defines.append('PIF_APP_REDUCED_THREADS=%s' % int(self.project_config['reduced_thread_usage']))
        if self.project_config['debug_info'] and self.project_config['p4_project']:
            common_defines.append('PIF_DEBUG=1')

        for opt_comp in OPTIONAL_COMPONENT_DEFAULTS:
            if opt_comp not in self.enabled_optional_components and opt_comp in OPTIONAL_COMPONENT_DISABLED_DEFINES:
                common_defines.append(OPTIONAL_COMPONENT_DISABLED_DEFINES[opt_comp])

        return common_defines

    def read_common_flags(self, target_tool):
        common_flags = self.app['common'][target_tool].get('flags', [])
        if self.project_config['debug_info']:
            common_flags.append(TOOL_ARGS_MAP[target_tool]['debug_info'])
        if self.project_config['nfcc_ng'] and target_tool == 'compiler':
            common_flags.append(TOOL_ARGS_MAP[target_tool]['nfcc_ng'])
        return common_flags

    def read_linker_flags(self):
        plflags = copy.copy(self.app['platforms'].get(self.platform, {}).get('common', {}).get(
            'linker', {}).get('flags', self.app['common']['linker']['flags']))

        if self.platform == 'starfighter1' and not self.project_config['simulator']:
            plflags.append('emu_cache_as_ddr.i26')

        return plflags

    def read_linker_pico_files(self):
        ppico = self.app['platforms'].get(self.platform, {}).get('common', {}).get(
            'linker', {}).get('pico', self.app['common']['linker']['pico'])
        return ppico.items()

    def read_component_path(self, comp):
        return os.path.abspath(os.path.normpath(self.components[comp]['dir']%self.app_vars))

    def get_build_info_json(self):
        return {
            'reduced_thread_usage': self.project_config['reduced_thread_usage'],
            'worker_mes': self.worker_mes,
            'simulation': self.project_config['simulator'],
            'debug_info': self.project_config['debug_info'],
            'sku': self.sku,
        }

    IID_ALIASES = {
        "arm":      1,    "pcie0":    4,    "pcie1":    5,    "pcie2":    6,
        "pcie3":    7,    "nbi0":     8,    "nbi1":     9,    "crypto0":  12,
        "crypto1":  13,   "emem0":    24,   "emem1":    25,   "emem2":    26,
        "imem0":    28,   "imem1":    29,   "mei0":     32,   "mei1":     33,
        "mei2":     34,   "mei3":     35,   "mei4":     36,   "mei5":     37,
        "mei6":     38,   "ila0":     48,   "ila1":     49,   "mac0":     52,
        "mac1":     53,
    }

    nfp6000_island_re  = re.compile("^i(\d+)(\.(.+))?$")

    def iid2tuple(self, iid):
        alias, trail = iid.split('.', 1)
        if alias in self.IID_ALIASES:
            return (self.IID_ALIASES[alias], int(trail[2:]))

        m = self.nfp6000_island_re.match(iid)
        if not m:
            raise ValueError("Not a valid NFP6000 resource ID: " + iid)
        return (int(m.group(1)), int(m.group(3)[2:]))

    def warn(self, msg):
        _warn(msg)

    def notify(self, msg):
        #pprint.pprint(msg)
        print msg

def generate_makefile(builder, p4_src, p4_tool_options, makefile_path,
                      custom_load_list, custom_load_me, custom_load_linker_args,
                      verbosity):

    def patternfn(fn):
        return '%'.join(fn.rsplit('.', 1))

    makefile_path_dir = os.path.dirname(makefile_path)

    p4_build = bool(len(p4_src))

    out = StringIO()
    target_names = builder.target_def.keys()

    if verbosity['generate']: builder.notify('generating makefile...')

    out.write('#\n# Generated Makefile for %s\n#\n\nifndef SDKDIR\nexport SDKDIR=%s\nendif\n\n'%(
        builder.project_name, SDK_ENV['SDKDIR'].replace('\\', '/')))
    out.write('ifndef SDKTOOLSDIR\nSDKTOOLSDIR=$(SDKDIR)/bin\nendif\n\n')
    out.write('ifndef SDKP4DIR\nSDKP4DIR=$(SDKDIR)/p4\nendif\n\n')
    out.write('ifndef OUTDIR\nOUTDIR=%s\nendif\n\n'%(relpath(builder.project_dir, makefile_path_dir)))
    if builder.pif_out_dir != builder.project_dir:
        out.write('ifndef PIFOUTDIR\nPIFOUTDIR=%s\nendif\n\n'%(
            relpath(builder.pif_out_dir, makefile_path_dir)))

    for ep in ENV_PATHS:
        if ep not in ('SDKTOOLSDIR', 'SDKP4DIR', 'OUTDIR', 'PIFOUTDIR'):
            out.write('ifndef %s\n$(error %s is not set)\nendif\n\n'%(ep, ep))

        # test that all required tools are available and executable
        for tool in ('$(SDKP4DIR)/bin/nfp4c',
                     '$(SDKP4DIR)/bin/nfirc',
                     '$(SDKTOOLSDIR)/nfld',
                     '$(SDKTOOLSDIR)/nfcc',
                     '$(SDKTOOLSDIR)/nfas'):
            tool_name = os.path.basename(tool)
            out.write('{tool_name_upper}_FOUND = $(shell if [ -x {tool} ]; then echo "found";  fi)\n'
                      'ifneq ($({tool_name_upper}_FOUND),found)\n'
                      '  $(warning warning: {tool_name} not found or not executable, on windows please run nfp4term.bat)\n'
                      'endif\n\n'.format(
                        tool_name_upper=tool_name.upper(),
                        tool_name=tool_name,
                        tool=tool))

    build_info_target = ''
    if builder.project_config['debug_info'] and builder.app_type != 'managed_c_app':
        build_info_target = '%(PIFOUTDIR_MF)s/build_info.json'%builder.app_vars

    # prepend list build output directory to targets
    full_targets = [s + builder.app_vars['os.sep'] + s for s in target_names]

    # add linker build target
    out.write('%s: %s \\\n'%(normpath(os.path.abspath(builder.nffw_output_filename)),
        ' \\\n\t\t'.join([normpath(os.path.join(builder.project_dir, t)) for t in full_targets])))
    if build_info_target:
        out.write('\t\t%s \\\n'%build_info_target)
    for cl in custom_load_list:
        # XXX try to change given path to relative to the makefile?
        out.write('\t\t%s \\\n'%cl)
    out.write('\t\t$(MAKEFILE_LIST)')

    out.write('\n\t@echo ---------\n')
    out.write('\t@echo linking $@\n')
    out.write('\t@echo ---------\n')
    plflags = list(builder.read_linker_flags())
    if verbosity['build']:
        plflags.append(TOOL_ARGS_MAP['linker']['verbose'])
    if builder.project_config['debug_info']:
        if builder.app_type != 'managed_c_app':
            plflags.append('user_note_f pif_debug_json "%(PIFOUTDIR_MF)s%(os.sep)spif_debug.json"'%builder.app_vars)
            plflags.append('user_note_f build_info_json "%(PIFOUTDIR_MF)s%(os.sep)sbuild_info.json"'%builder.app_vars)
        plflags.append(TOOL_ARGS_MAP['linker']['debug_info'])
    if builder.app_type != 'managed_c_app':
        plflags.append('user_note_f pif_design_json "%(PIFOUTDIR_MF)s%(os.sep)spif_design.json"'%builder.app_vars)
    lflags = ' '.join([TOOL_ARGS_MAP['linker']['flags']%(lf%builder.app_vars) for lf in plflags])
    if custom_load_linker_args:
        lflags = '%s %s'%(lflags, ' '.join(custom_load_linker_args))
    pico = ' \\\n\t\t'.join([TOOL_ARGS_MAP['linker']['pico']%(pi, normpath(os.path.join(SDK_ENV['SDKDIR'],
        'components', 'standardlibrary', 'picocode', 'nfp6000', pf, pf+'.npfw')))
        for (pi, pf) in builder.read_linker_pico_files()])
    out.write('\t%s %s \\\n\t\t%s \\\n\t\t-chip %s -g -o $@ '%(
        normpath(os.path.join(SDK_ENV['SDKTOOLSDIR'], 'nfld')), lflags, pico, builder.sku))
    for t, ft in zip(target_names, full_targets):
        if t in builder.codeless_targets:
            continue
        lp = normpath(os.path.join(builder.project_dir, ft))
        out.write('\\\n\t\t-u %s %s '%(' \\\n\t\t\t'.join(textwrap.wrap(' '.join(builder.list_mes[t]), 60)), lp))
    for cl, cme in zip(custom_load_list, custom_load_me):
        out.write('\\\n\t\t-u %s %s '%(cme, cl))
    for scs in builder.scs_defs:
        out.write('\\\n\t\t-codeshare %s '%scs)
    if builder.scs_defs:
        out.write('\\\n\t\t-noecc')
    for ct in builder.codeless_targets:
        ct = normpath(os.path.join(builder.project_dir, ct + builder.app_vars['os.sep'] + ct))
        out.write('\\\n\t\t-L %s '%ct)

    if build_info_target:
        out.write('\n\n#\n# Generate build info json\n#\n\n')
        out.write('%s: $(MAKEFILE_LIST)'%build_info_target)
        out.write('\n\t@echo ---------\n')
        out.write('\t@echo generating $@\n')
        out.write('\t@echo ---------\n')
        out.write('\t@mkdir -p %(PIFOUTDIR_MF)s\n'%builder.app_vars)
        out.write('\t@echo -n %s >$@\n'%json.dumps(builder.get_build_info_json()).replace('"', '\\"'))

    if p4_build and p4_src:
        p4version = p4_tool_options['nfp4c']['--p4-version'] if p4_tool_options['nfp4c']['--p4-version'] is not None else DEFAULT_P4_VERSION
        p4compiler = p4_tool_options['nfp4c']['--p4-compiler'] if p4_tool_options['nfp4c']['--p4-compiler'] is not None else DEFAULT_P4_COMPILER

        # build additional nfp4c options
        nfp4c_additional_options = []
        if p4_tool_options['nfp4c']['--graphs']:
            for (svgp, svgf) in (('p', 'parse'), ('i', 'ingress'), ('e', 'egress')):
                nfp4c_additional_options.append('-%s %s'%(svgp,
                    normpath(os.path.join(builder.project_dir, '%s_%s.svg'%(builder.project_name, svgf)))))
        del p4_tool_options['nfp4c']['--graphs']
        if p4_tool_options['nfp4c']['-D']:
            nfp4c_additional_options.extend(['-D %s'%v for v in p4_tool_options['nfp4c']['-D']])
        del p4_tool_options['nfp4c']['-D']
        if p4_tool_options['nfp4c']['-I']:
            nfp4c_additional_options.extend(['-I %s'%relpath(v, makefile_path_dir) for v in p4_tool_options['nfp4c']['-I']])
            del p4_tool_options['nfp4c']['-I']
        if p4compiler == 'hlir':
            # add include path for standard intrinsic metadata
            nfp4c_additional_options.append('-I %s'%normpath(os.path.join(SDK_ENV['SDKP4DIR'], 'include', p4version, 'p4_lib', 'target')))
        if verbosity['build']:
            nfp4c_additional_options.append('-v')

        for p4o, p4v in p4_tool_options['nfp4c'].items():
            if p4v is not None:
                if isinstance(p4v, bool):
                    if p4v:
                        p4v = ''
                    else:
                        continue
                nfp4c_additional_options.append('%s %s'%(p4o, p4v))
        nfp4c_additional_options = ' \\\n\t\t'.join(nfp4c_additional_options)

        # add target to generate yml/svg to out from p4
        out.write('\n\n#\n# Generate IR from P4\n#\n\n')
        yml_file = normpath(os.path.join(builder.project_dir, builder.project_name+'.yml'))
        p4_src_paths = ' \\\n\t\t'.join([relpath(p4s, makefile_path_dir) for p4s in p4_src]+['$(MAKEFILE_LIST)'])
        out.write('%s: %s\n'%(yml_file, p4_src_paths))
        out.write('\t@echo ---------\n\t@echo compiling p4 $@\n\t@echo ---------\n')
        out.write('\t@mkdir -p %(PIFOUTDIR_MF)s\n'%builder.app_vars)
        out.write('\t%s -o %s \\\n\t\t%s \\\n'%(
            normpath(os.path.join(SDK_ENV['SDKP4DIR'], 'bin', 'nfp4c')), yml_file, nfp4c_additional_options))
        out.write('\t\t%s\n'%relpath(p4_src[0], makefile_path_dir))

        # build additional nfirc options
        nfirc_additional_options = []
        if verbosity['build']:
            nfirc_additional_options.append('--verbose')
        if p4_tool_options['nfirc']['--graphs']:
            nfirc_additional_options.extend(['--globalgraph', '--parsegraph'])
        del p4_tool_options['nfirc']['--graphs']
        if p4version == '16' or p4compiler == 'p4c-nfp':
            nfirc_additional_options.append('--p4info %s'%normpath(os.path.join(builder.project_dir, builder.project_name+'.p4info.json')))
        for p4o, p4v in p4_tool_options['nfirc'].items():
            if p4v is not None:
                if isinstance(p4v, bool):
                    if p4v:
                        p4v = ''
                    else:
                        continue
                nfirc_additional_options.append('%s %s'%(p4o, p4v))
        nfirc_additional_options = ' \\\n\t\t'.join(nfirc_additional_options)

        # add targets to setup dependencies between pif generated source files and yml and generate pif
        out.write('\n\n#\n# Generate PIF from IR\n#\n\n')
        # by making the rule a pattern match rule % we force make to generate all files in a single command
        # this is needed for parallel builds
        out.write((' \\\n'.join([ patternfn(normpath(os.path.join(builder.components['pif_gen']['dir']%builder.app_vars, p%builder.app_vars)))
            for p in builder.components['pif_gen']['compiler']['dependencies'] ])) + ' : %s $(MAKEFILE_LIST) \n'%patternfn(yml_file))
        out.write('\t@echo ---------\n\t@echo generating pif $@\n\t@echo ---------\n')
        out.write('\t@mkdir -p %(PIFOUTDIR_MF)s\n'%builder.app_vars)
        out.write('\t%s -o %s \\\n\t\t%s \\\n'%(
            normpath(os.path.join(SDK_ENV['SDKP4DIR'], 'bin', 'nfirc')),
                normpath(builder.pif_out_dir), nfirc_additional_options))
        out.write('\t\t%s\n'%yml_file)

    for t,ft in zip(target_names, full_targets):
        lp = normpath(os.path.join(builder.project_dir, ft))
        out.write('\n\n#\n# %s\n#\n\n'%os.path.splitext(t)[0].upper())

        # add compiler build targets
        if builder.target_def[t]['compiler']['add']:
            defines = [TOOL_ARGS_MAP['compiler']['define']%(ppd%builder.app_vars)
                       for ppd in builder.target_def[t]['compiler']['defines']]
            flags = [TOOL_ARGS_MAP['compiler']['flag']%(cf%builder.app_vars)
                     for cf in builder.target_def[t]['compiler']['flags']]
            includes = [TOOL_ARGS_MAP['compiler']['include']%fi
                        for fi in builder.target_def[t]['compiler']['include']]
            force_includes = [TOOL_ARGS_MAP['compiler']['forceinclude']%i
                              for i in builder.target_def[t]['compiler']['forceinclude']]
            out.write('%s: %s\n'%(lp, ' \\\n\t'.join(builder.target_def[t]['compiler']['src']+
                builder.target_def[t]['compiler']['dependencies']+['$(MAKEFILE_LIST)'])))
            out.write('\t@echo ---------\n\t@echo compiling $@\n\t@echo ---------\n')
            out.write('\t@mkdir -p %s\n' %(normpath(os.path.join(builder.project_dir, t))))
            out.write('\t%s %s \\\n\t-chip %s \\\n\t%s \\\n\t%s \\\n\t%s \\\n'%(
                normpath(os.path.join(SDK_ENV['SDKTOOLSDIR'], 'nfcc')),
                ' \\\n\t'.join(defines), builder.sku, ' \\\n\t'.join(flags),
                ' \\\n\t'.join(includes), ' \\\n\t'.join(force_includes)))
            opath = normpath(os.path.join(builder.project_dir, t))
            out.write('\t-Fo%s%s \\\n\t-Fe%s $(NFCC_FLAGS) \\\n\t'%(opath, builder.app_vars['os.sep'], os.path.splitext(lp)[0]))
            out.write(' \\\n\t'.join(builder.target_def[t]['compiler']['src']))

        # add assembler build targets
        if builder.target_def[t]['assembler']['add']:
            defines = [TOOL_ARGS_MAP['assembler']['define']%(ppd%builder.app_vars)
                       for ppd in builder.target_def[t]['assembler']['defines']]
            flags = [TOOL_ARGS_MAP['assembler']['flag']%(cf%builder.app_vars)
                     for cf in builder.target_def[t]['assembler']['flags']]
            includes = [TOOL_ARGS_MAP['assembler']['include']%fi
                        for fi in builder.target_def[t]['assembler']['include']]
            force_includes = [TOOL_ARGS_MAP['assembler']['forceinclude']%i
                              for i in builder.target_def[t]['assembler']['forceinclude']]
            out.write('%s: %s\n'%(lp, ' \\\n\t'.join(builder.target_def[t]['assembler']['src']+
                builder.target_def[t]['assembler']['dependencies']+['$(MAKEFILE_LIST)'])))
            out.write('\t@echo ---------\n\t@echo assembling $@\n\t@echo ---------\n')
            out.write('\t@mkdir -p %s\n' %(normpath(os.path.join(builder.project_dir, t))))
            out.write('\t%s %s \\\n\t-chip %s \\\n\t%s \\\n\t%s \\\n\t%s \\\n'%(
                normpath(os.path.join(SDK_ENV['SDKTOOLSDIR'], 'nfas')),
                ' \\\n\t'.join(defines), builder.sku, ' \\\n\t'.join(flags),
                ' \\\n\t'.join(includes), ' \\\n\t'.join(force_includes)))
            out.write('\t-o $@ %s\n'%builder.target_def[t]['assembler']['root'])

    # define target to clean all output
    pd = normpath(builder.project_dir)
    out.write('\nclean:\n')
    out.write('\trm -f {0}*.nffw {0}*.elf \\\n\t\t{0}*.mif {0}*.mift \\\n'
              '\t\t{0}*.uci {0}*.ucp \\\n\t\t{0}*.dbg\n'.format(pd))
    for t in target_names:
        out.write('\trm -rf %s\n'%normpath(os.path.join(builder.project_dir, t)))
    if p4_build:
        out.write('\trm -f {0}*.yml {0}*.svg \n'.format(pd))
        pd = normpath(builder.pif_out_dir)
        out.write('\trm -f {0}*.c {0}*.h {0}*.json \\\n\t\t{0}*.txt '
                  '{0}*.svg {0}*.csv \n'.format(pd))
        out.write('\trm -rf %scallbackapi\n'%pd)

    # only update makefile if it doesn't exist or it has changed
    changes = True
    if os.path.isfile(makefile_path):
        with open(makefile_path) as current_makefile:
            data = current_makefile.read()
            if data == out.getvalue():
                changes = False

    if changes:
        # write out collected targets as a Makefile
        if not os.path.isdir(makefile_path_dir):
            os.makedirs(makefile_path_dir)

        with open(makefile_path, 'w') as out_file:
            out_file.write(out.getvalue())
    else:
        builder.warn('makefile not written, no changes')


def makefile_from_json_pif_targets(nffw_output_filename, pif_out_dir, sku,
        makefile_path='Makefile-nfp4build', app_type=DEFAULT_APP_TYPE,
        platform=DEFAULT_PLATFORM, override_platform_json=None,
        sandbox_c=None, variant=None, reduced_thread_usage=False, p4_src=[],
        p4_tool_options={'nfp4c': {}, 'nfirc': {}},
        block_make=False, make_cpu_count=None, simulator=False,
        shared_codestore=False, debug_info=True, c_includes=[], c_defines=[],
        enabled_optional_components=[k for k, v in OPTIONAL_COMPONENT_DEFAULTS.items() if v],
        application_me_count=-1, nfcc_ng=False,
        custom_load_list=[], custom_load_me=[], custom_load_linker_args=(),
        make_output_sync=False,
        verbosity={'generate': False, 'build': False}):

    if 'SDKDIR' in os.environ:
        SDK_ENV['SDKDIR'] = os.environ['SDKDIR']

    # running as a binary
    if hasattr(sys, 'frozen'):
        # check relative paths when running as a binary
        if not SDK_ENV['SDKDIR']:
            sdk_dir = os.path.normpath(os.path.abspath(
                os.path.join(os.path.dirname(sys.executable), '..', '..')))
            if os.path.isdir(os.path.join(sdk_dir, 'p4', 'include')):
                SDK_ENV['SDKDIR'] = sdk_dir
            else:
                raise Exception, 'SDKDIR not set and binary not located in toolchain'
        pif_root_dir = os.path.abspath(os.path.normpath(os.path.join(SDK_ENV['SDKDIR'],
            'p4', 'components', 'nfp_pif')))

    # running from the repo
    else:
        pif_root_dir = os.path.abspath(os.path.normpath(os.path.join(os.path.dirname(__file__),
            '..', '..', '..', '..')))
        if not SDK_ENV['SDKDIR']:
            sdk_dir = os.path.normpath(os.path.abspath(
                os.path.join(pif_root_dir, '..')))
            if os.path.isdir(os.path.join(sdk_dir, 'p4', 'include')):
                SDK_ENV['SDKDIR'] = sdk_dir
            else:
                raise Exception, 'SDKDIR not set and source not run from repo'

    SDK_ENV['SDKTOOLSDIR'] = os.environ.get('SDKTOOLSDIR', os.path.join(SDK_ENV['SDKDIR'], 'bin'))
    SDK_ENV['SDKP4DIR'] = os.environ.get('SDKP4DIR', os.path.join(SDK_ENV['SDKDIR'], 'p4'))

    p4_build = bool(len(p4_src))

    if p4_build and app_type == 'managed_c_app':
        raise Exception, 'P4 source files are not allowed for managed c apps'

    if (len(c_includes)) and sandbox_c is None:
        _warn('includes or defines specified without c files.')

    project_config = {
        'simulator': simulator,
        'shared_codestore': shared_codestore,
        'debug_info': debug_info,
        'reduced_thread_usage': reduced_thread_usage,
        'application_me_count': application_me_count,
        'nfcc_ng': nfcc_ng,
        'p4_project': len(p4_src) > 0,
    }
    apps_base = os.environ.get('APPSBASE', None)

    builder = PIFJSONBuilder(nffw_output_filename, pif_root_dir, pif_out_dir,
        app_type, project_config, enabled_optional_components)
    builder.load(apps_base, variant)

    # component dirs follow the [sdk_root]/p4/components/[name] windows format
    # prefix default component with sdk root unless dir is already defined (abs)
    for comp in builder.components:
        p = builder.components[comp]['dir']%builder.app_vars
        d = os.path.join(SDK_ENV['SDKDIR'], p)
        if not os.path.isabs(p):
            if os.path.isdir(d):
                builder.components[comp]['dir'] = d
            else:
                builder.components[comp]['dir'] = os.path.join(os.path.dirname(SDK_ENV['SDKP4DIR']), p)

    # override component paths if env vars exist
    # record path prefixes and reorder in replacement search order
    for comp, env in COMPONENT_ENV_PATHS.items():
        if env in os.environ and comp in builder.components:
            builder.components[comp]['dir'] = os.environ[env]
            if env not in ENV_PATHS:
                ENV_PATHS[env] = builder.components[comp]['dir']
    ENV_PATHS['OUTDIR'] = builder.project_dir
    ENV_PATHS['SDKTOOLSDIR'] = SDK_ENV['SDKTOOLSDIR']
    if builder.pif_out_dir != builder.project_dir:
        ENV_PATHS['PIFOUTDIR'] = builder.pif_out_dir
    ENV_PATHS['SDKP4DIR'] = SDK_ENV['SDKP4DIR']
    for env, pth in ENV_PATHS.items():
        PATH_PREFIXES.append( (pth.replace('\\', '/') if MINGW_PATHS else pth, env) )

    PATH_PREFIXES.sort(key=lambda t: len(t[0]), reverse=True)
    PATH_PREFIXES.append( (SDK_ENV['SDKDIR'].replace('\\', '/') if MINGW_PATHS else SDK_ENV['SDKDIR'], 'SDKDIR') )

    builder.app_vars['PIFOUTDIR_MF'] = '$(OUTDIR)' if builder.pif_out_dir == builder.project_dir else '$(PIFOUTDIR)'

    if verbosity['generate']:
        builder.notify('configured environment:')
        used = set()
        for n, v in PATH_PREFIXES:
            builder.notify('\t%s: %s'%(v, n))
            used.add(v)
        unused = set(COMPONENT_ENV_PATHS.values()).difference(used)
        if unused:
            builder.notify('environment variables not set:')
            for n in unused:
                builder.notify('\t%s'%n)

        builder.notify('optional component state:')
        for comp in OPTIONAL_COMPONENT_DEFAULTS:
            builder.notify('\t%s: %s'%(comp, 'enabled' if comp in builder.enabled_optional_components else 'disabled'))

    src_base_dir = os.path.dirname(os.path.abspath(makefile_path))

    builder.process_targets(sku, platform, override_platform_json,
            p4_src, sandbox_c, c_includes, c_defines, src_base_dir,
            custom_load_list, custom_load_me, custom_load_linker_args,
            verbosity)

    generate_makefile(builder,
            p4_src, p4_tool_options, makefile_path,
            custom_load_list, custom_load_me, custom_load_linker_args,
            verbosity)

    # build the makefile
    if not block_make:
        # warn if make can not be found
        try:
            subprocess.call(['make', '--version'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        except OSError, err:
            if err.errno == 2:
                if sys.platform == 'win32':
                    msg = 'make could not be found, please setup your build environment by running nfp4term.bat'
                else:
                    msg = 'make could not be found, please setup your build environment'
                builder.warn(msg)
            else:
                raise

        if verbosity['generate']: builder.notify('running makefile...')

        if make_cpu_count is None:
            make_cpu_count = multiprocessing.cpu_count()

        # run make
        ret = subprocess.call(['make',
            '-j%s'%make_cpu_count,
            '-f%s'%os.path.basename(makefile_path),
            '-C%s'%os.path.dirname(makefile_path).replace('\\', '/')] + \
            (['-O'] if make_output_sync else []))
        if ret:
            raise Exception, 'Firmware build failed'


def main():
    parser = argparse.ArgumentParser(
        description='%s\n\n%s'%(DESCRIPTION, NOTES),
        epilog='Copyright (C) 2016-2018 Netronome Systems, Inc.  All rights reserved.',
        formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--version', action='version', version=VERSION)
    parser.add_argument('-o', '--output-nffw-filename', dest='output_nffw_filename', action='store',
                        default=None, required=True,
                        help='output nffw filename (directory also used for other output)')
    parser.add_argument('-p', '--pif-output-dir', dest='pif_output_dir', action='store', default=None,
                        help='pif output directory')
    parser.add_argument('-m', '--makefile', dest='makefile', action='store',
                        default=os.path.join('.', 'Makefile-nfp4build'),
                        help='makefile filename to generate')
    parser.add_argument('-s', '--sku', dest='sku', action='store', default=None,
                        help='sku')
    parser.add_argument('-a', '--application-type', dest='app_type', action='store', default=DEFAULT_APP_TYPE,
                        help='application type (pif_app, pif_app_nfd, managed_c_app)')
    parser.add_argument('-l', '--platform', dest='platform', action='store', default=DEFAULT_PLATFORM,
                        choices=('bataan', 'hydrogen', 'starfighter1', 'lithium', 'beryllium', 'carbon'),
                        help='platform name')
    parser.add_argument('-A', '--application-me-count', dest='application_me_count', action='store', default=None, type=int,
                        help='number of application MEs to instantiate, default is maximum mes')
    parser.add_argument('-j', '--override-platform-json', dest='override_platform_json', action='store', default=None,
                        help='custom json file that can override platform definitions.')
    parser.add_argument('-c', '--sandbox-c', dest='sandbox_c', action='store', nargs='+', default=None,
                        help='one or more sandbox c files')
    parser.add_argument('-v', '--variant', dest='variant', action='store', default=None,
                        help='custom variant')
    parser.add_argument('-r', '--reduced-thread-usage', dest='reduced_thread_usage', action='store_true', default=True,
                        help='use 4-context mode for microengines; this reduces memory usage by half but reduces performance')
    parser.add_argument('--no-reduced-thread-usage', dest='reduced_thread_usage', action='store_false', default=True,
                        help='use 8-context mode for microengines')
    parser.add_argument('-4', '--incl-p4-build', dest='p4_src', action='store', nargs='+', default=[],
                        help='one or more p4 source files, if defined also include p4 to pif c make targets in build. '
                             'the first p4 file is used as the main file and all others as build dependencies')
    parser.add_argument('-b', '--block-make', dest='block_make', action='store_true', default=False,
                        help='prevent make from running after makefile generaration')
    parser.add_argument('-u', '--make-cpu-count', dest='make_cpu_count', action='store', default=None,
                        help='force the number of cpus used, default is auto-detected number of cpus')
    parser.add_argument('-i', '--simulator', dest='simulator', action='store_true', default=False,
                        help='build for simulator')
    parser.add_argument('-e', '--shared-codestore', dest='shared_codestore', action='store_true', default=False,
                        help='build with shared codestore support')
    parser.add_argument('--no-shared-codestore', dest='shared_codestore', action='store_false', default=False,
                        help='build without shared codestore support')
    parser.add_argument('-n', '--debug-info', dest='debug_info', action='store_true', default=True,
                        help='build with debug information for breakpoints and stepping')
    parser.add_argument('--no-debug-info', dest='debug_info', action='store_false', default=True,
                        help='build without debug information for breakpoints and stepping')
    parser.add_argument('-I', '--include', dest='includes', type=str, action='append', default=[],
                        help='include path to be added for sandbox/managed c code')
    parser.add_argument('-D', '--define', dest='defines', type=str, action='append', default=[],
                        help='define to be added for sandbox/managed c code')
    parser.add_argument('-d', '--disable-component', dest='disabled_components', type=str, action='append',
                        default=[n for n, v in OPTIONAL_COMPONENT_DEFAULTS.items() if not v],
                        choices=[n for n, v in OPTIONAL_COMPONENT_DEFAULTS.items() if v],
                        help='disable optional components')
    parser.add_argument('--enable-component', dest='enabled_components', type=str, action='append',
                        default=[n for n, v in OPTIONAL_COMPONENT_DEFAULTS.items() if v],
                        choices=[n for n, v in OPTIONAL_COMPONENT_DEFAULTS.items() if not v],
                        help='enable optional components')
    parser.add_argument('-g', '--nfcc-ng', dest='nfcc_ng', action='store_true', default=True,
                        help='build for nfcc ng')
    parser.add_argument('--no-nfcc-ng', dest='nfcc_ng', action='store_false', default=True,
                        help='build for nfcc')
    parser.add_argument('--custom-load-list', dest='custom_load_list', type=str, action='append', default=[],
                        help='list file for custom load')
    parser.add_argument('--custom-load-me', dest='custom_load_me', type=str, action='append', default=[],
                        help='me for custom load')
    parser.add_argument('--custom-load-linker-arg', dest='custom_load_linker_args', type=str, action='append', default=[],
                        help='linker arguments for custom load')
    parser.add_argument('--debug-script', dest='debug_script', action='store_true', default=False,
                        help=argparse.SUPPRESS)
    parser.add_argument('--verbose-generate', dest='verbose_generate', action='store_true', default=False,
                        help='print verbose information during makefile generation')
    parser.add_argument('--verbose-build', dest='verbose_build', action='store_true', default=False,
                        help='print verbose information during build')
    parser.add_argument('--make-output-sync', dest='make_output_sync', action='store_true', default=False,
                        help='seperate build output from each process')

    # nfp4c routed options
    parser.add_argument('--nfp4c_graphs', action='store_true', default=None,
                        help='generate IR graphs for parse, ingress and egress')
    parser.add_argument('--nfp4c_custom_primitives', type=str, default=None,
                        help="p4 custom primitives JSON")
    parser.add_argument('--nfp4c_D', dest='nfp4c_defines', type=str, action='append', default=None,
                        help="p4 preprocessor defines")
    parser.add_argument('--nfp4c_I', dest='nfp4c_includes', type=str, action='append', default=None,
                        help="p4 preprocessor include paths")
    parser.add_argument('--nfp4c_p4_version', dest='nfp4c_p4_version', type=str, default=None,
                        choices=('1.0', '1.1', '14', '16'),
                        help="p4 language version, default %s"%DEFAULT_P4_VERSION)
    parser.add_argument('--nfp4c_p4_compiler', dest='nfp4c_p4_compiler', type=str, default=None,
                        choices=('hlir', 'p4c-nfp'),
                        help="p4 source compiler used for AIR generation, default %s"%DEFAULT_P4_COMPILER)

    # nfirc routed options
    parser.add_argument('--nfirc_default_table_size', type=int, default=None,
                        help="default table size to apply if none specified")
    parser.add_argument('--nfirc_inline_fixed_table_entries', type=int, default=None,
                        help="default table size to apply if none specified")
    parser.add_argument('--nfirc_all_header_ops', action="store_true", default=None,
                        help="allow all headers to be addable/removable")
    parser.add_argument('--nfirc_no_all_header_ops', action="store_false", default=None,
                        dest='nfirc_all_header_ops',
                        help="do not allow all headers to be addable/removable")
    parser.add_argument('--nfirc_implicit_header_valid', action="store_true", default=None,
                        help="enable P4 implicit header valid matching semantics")
    parser.add_argument('--nfirc_no_implicit_header_valid', action="store_false", default=None,
                        dest='nfirc_implicit_header_valid',
                        help="do not enable P4 implicit header valid matching semantics")
    parser.add_argument('--nfirc_graphs', action="store_true", default=None,
                        help="generate PIF graphs for parse and global control")
    parser.add_argument('--nfirc_zero_new_headers', action="store_true", default=None,
                        help="strict P4 behaviour of zeroing all new headers")
    parser.add_argument('--nfirc_no_zero_new_headers', action="store_false", default=None,
                        dest='nfirc_zero_new_headers',
                        help="no strict P4 behaviour of zeroing all new headers")
    parser.add_argument('--nfirc_multicast_group_count', type=int, default=None,
                        help="number of multicast groups to support")
    parser.add_argument('--nfirc_multicast_group_size', type=int, default=None,
                        help="maximum number of multicast ports per group")
    parser.add_argument('--nfirc_mac_ingress_timestamp', action="store_true", default=None,
                        help="use the MAC timestamp rather than ME timestamp "
                             "for intrinsic ingress timestamp metadata")
    parser.add_argument('--nfirc_no_mac_ingress_timestamp', action="store_false", default=None,
                        dest='nfirc_mac_ingress_timestamp',
                        help="do not use the MAC timestamp rather than ME timestamp "
                             "for intrinsic ingress timestamp metadata")

    options = parser.parse_args()

    p4_tool_options = {
        'nfp4c': {
            '--graphs': options.nfp4c_graphs,
            '-c': options.nfp4c_custom_primitives,
            '-D': options.nfp4c_defines,
            '-I': options.nfp4c_includes,
            '--p4-version': options.nfp4c_p4_version,
            '--p4-compiler': options.nfp4c_p4_compiler,
            '--source_info': True,
        },
        'nfirc': {
            '--debugpoints': options.debug_info,

            '--graphs': options.nfirc_graphs,
            '--default_table_size': options.nfirc_default_table_size,
            '--inline_fixed_table_entries': options.nfirc_inline_fixed_table_entries,
            '--all_header_ops': options.nfirc_all_header_ops,
            '--no_all_header_ops': not options.nfirc_all_header_ops if options.nfirc_all_header_ops is not None else None,
            '--implicit_header_valid': options.nfirc_implicit_header_valid,
            '--no_implicit_header_valid': not options.nfirc_implicit_header_valid if options.nfirc_implicit_header_valid is not None else None,
            '--zero_new_headers': options.nfirc_zero_new_headers,
            '--no_zero_new_headers': not options.nfirc_zero_new_headers if options.nfirc_zero_new_headers is not None else None,
            '--multicast_group_count': options.nfirc_multicast_group_count,
            '--multicast_group_size': options.nfirc_multicast_group_size,
            '--mac_ingress_timestamp': options.nfirc_mac_ingress_timestamp,
            '--no_mac_ingress_timestamp': not options.nfirc_mac_ingress_timestamp if options.nfirc_mac_ingress_timestamp is not None else None,
        }
    }

    verbosity = {
        'generate': options.verbose_generate,
        'build': options.verbose_build,
    }

    delta_disabled_components = set(options.disabled_components) - set([n for n, v in OPTIONAL_COMPONENT_DEFAULTS.items() if not v])
    enabled_optional_components = set([n for n, v in OPTIONAL_COMPONENT_DEFAULTS.items() if v]) | set(options.enabled_components)
    enabled_optional_components -= set(delta_disabled_components)

    try:
        makefile_from_json_pif_targets(options.output_nffw_filename, options.pif_output_dir,
            options.sku, options.makefile, options.app_type, options.platform,
            options.override_platform_json, options.sandbox_c, options.variant,
            options.reduced_thread_usage, options.p4_src, p4_tool_options,
            options.block_make, options.make_cpu_count, options.simulator,
            options.shared_codestore, options.debug_info, options.includes,
            options.defines, enabled_optional_components, options.application_me_count, options.nfcc_ng,
            options.custom_load_list, options.custom_load_me, options.custom_load_linker_args,
            options.make_output_sync, verbosity)

    except Exception, err:
        if options.debug_script:
            raise
        else:
            print >> sys.stderr, "error: %s"%str(err)
            sys.exit(1)


if __name__ == '__main__':
    main()
